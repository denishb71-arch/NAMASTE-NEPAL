import { useState, useEffect } from "react";
import { auth, db } from "./lib/firebase";
import { onAuthStateChanged, signOut, User } from "firebase/auth";
import { collection, query, limit, onSnapshot, addDoc } from "firebase/firestore";
import { LoadingScreen } from "./components/LoadingScreen";
import { Auth } from "./components/Auth";
import { TripPlanner } from "./components/TripPlanner";
import { HealthDashboard } from "./components/HealthDashboard";
import { MapComponent } from "./components/MapComponent";
import { Button, Card, Input } from "./components/ui-minimal";
import { handleFirestoreError, OperationType } from "./lib/firebase";
import { getPersonalizedRecommendations } from "./services/geminiService";
import { cn } from "./lib/utils";
import { 
  Mountain, 
  Map as MapIcon, 
  HeartPulse, 
  Car, 
  Globe, 
  LogOut, 
  Camera, 
  Plus, 
  Star,
  Plane,
  Hotel,
  Sparkles,
  MapPin
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type Tab = "explore" | "planner" | "health" | "vehicles" | "bookings";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>("explore");
  const [showLoading, setShowLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setInitializing(false);
      // Extra delay for the aesthetic loading screen
      setTimeout(() => setShowLoading(false), 2000);
    });
    return unsub;
  }, []);

  if (initializing) return <LoadingScreen />;

  return (
    <div className="min-h-screen bg-stone-50 selection:bg-nepal-red/20">
      <AnimatePresence>
        {showLoading && <LoadingScreen />}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {!user ? (
          <motion.div key="auth" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Auth />
          </motion.div>
        ) : (
          <div className="flex flex-col min-h-screen">
            {/* Header */}
            <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-stone-200">
              <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mountain className="w-8 h-8 text-nepal-red" />
                  <span className="font-serif text-xl tracking-tight">Namaste Nepal</span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="hidden md:flex items-center gap-1 px-4 py-1.5 bg-stone-100 rounded-full">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-[10px] uppercase font-bold text-stone-500 tracking-wider">Himalaya Server Online</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    onClick={() => signOut(auth)}
                    className="p-2 h-10 w-10 !rounded-full hover:bg-stone-100"
                  >
                    <LogOut className="w-4 h-4 text-stone-600" />
                  </Button>
                  <div className="w-9 h-9 rounded-full bg-nepal-blue flex items-center justify-center text-white text-xs font-bold border-2 border-white shadow-sm overflow-hidden">
                    {user.photoURL ? <img src={user.photoURL} alt="User" /> : user.email?.charAt(0).toUpperCase()}
                  </div>
                </div>
              </div>
            </header>

            {/* Sub-nav */}
            <nav className="bg-white border-b border-stone-200 overflow-x-auto no-scrollbar">
              <div className="max-w-7xl mx-auto px-4 flex gap-8">
                <NavTab active={activeTab === 'explore'} onClick={() => setActiveTab('explore')} icon={<Globe />} label="Explore" />
                <NavTab active={activeTab === 'planner'} onClick={() => setActiveTab('planner')} icon={<MapIcon />} label="Trip Planner" />
                <NavTab active={activeTab === 'health'} onClick={() => setActiveTab('health')} icon={<HeartPulse />} label="Health Body" />
                <NavTab active={activeTab === 'vehicles'} onClick={() => setActiveTab('vehicles')} icon={<Car />} label="Rentals" />
                <NavTab active={activeTab === 'bookings'} onClick={() => setActiveTab('bookings')} icon={<Plane />} label="Bookings" />
              </div>
            </nav>

            {/* Main Content */}
            <main className="flex-grow max-w-7xl mx-auto w-full px-4 py-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {renderTabContent(activeTab)}
                </motion.div>
              </AnimatePresence>
            </main>

            {/* Footer */}
            <footer className="bg-stone-900 text-white py-12">
              <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12 border-t border-stone-800 pt-12">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Mountain className="w-6 h-6 text-nepal-red" />
                    <span className="font-serif text-lg">Namaste Nepal Travel</span>
                  </div>
                  <p className="text-stone-400 text-sm leading-relaxed">
                    Connecting adventurers to the heart of the Himalayas. Powered by AI and community passion.
                  </p>
                </div>
                <div className="space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-stone-500">Quick Actions</h4>
                  <ul className="text-sm space-y-2 text-stone-300">
                    <li><button className="hover:text-white transition-colors">Emergency Contacts</button></li>
                    <li><button className="hover:text-white transition-colors">Permit Information</button></li>
                    <li><button className="hover:text-white transition-colors">Porter Services</button></li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-stone-500">Navigation</h4>
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 cursor-pointer transition-all">
                      <Globe className="w-5 h-5 text-stone-400" />
                    </div>
                    <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 cursor-pointer transition-all">
                      <MapIcon className="w-5 h-5 text-stone-400" />
                    </div>
                  </div>
                </div>
              </div>
            </footer>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavTab({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "py-4 flex items-center gap-2 border-b-2 transition-all whitespace-nowrap px-1",
        active ? "border-nepal-red text-nepal-red" : "border-transparent text-stone-500 hover:text-stone-800"
      )}
    >
      <span className={cn("w-4 h-4", active ? "text-nepal-red" : "text-stone-400")}>{icon}</span>
      <span className="text-sm font-medium tracking-tight">{label}</span>
      {active && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-nepal-red" />}
    </button>
  );
}

function renderTabContent(tab: Tab) {
  switch (tab) {
    case 'explore': return <ExploreView />;
    case 'planner': return <TripPlanner />;
    case 'health': return <HealthDashboard />;
    case 'vehicles': return <VehiclesView />;
    case 'bookings': return <BookingsView />;
  }
}

function ExploreView() {
  const [recommendations, setRecommendations] = useState<any>(null);
  const [loadingAI, setLoadingAI] = useState(false);

  useEffect(() => {
    const fetchAI = async () => {
      setLoadingAI(true);
      try {
        const res = await getPersonalizedRecommendations("adventure, mountains", "past trek in Annapurna");
        setRecommendations(res);
      } catch (e) {
        console.error(e);
      } finally {
        setLoadingAI(false);
      }
    };
    fetchAI();
  }, []);

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-6">
          <h2 className="text-5xl font-serif leading-tight">Escape to the <br /><span className="text-nepal-red italic">Infinite Horizon</span></h2>
          <p className="text-stone-600 leading-relaxed max-w-md">
            Explore the mystical landscapes of Nepal—from the lush jungles of Terai to the crystalline peaks of the high Himalayas.
          </p>
          <div className="flex gap-4">
            <Button>Quick Start</Button>
            <Button variant="outline">Learn More</Button>
          </div>
        </div>
        <MapComponent 
          currentLocation={{ lat: 27.7172, lng: 85.3240, name: "Kathmandu Valley" }}
          destination={{ lat: 28.2096, lng: 83.9856, name: "Pokhara Lakeside" }}
          viewMode="satellite"
        />
      </div>

      <AnimatePresence>
        {recommendations && (
          <motion.section initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-8 bg-nepal-blue/5 rounded-3xl border border-nepal-blue/10 space-y-6">
            <div className="flex items-center gap-3">
              <Sparkles className="w-6 h-6 text-nepal-blue" />
              <h3 className="text-2xl font-serif text-nepal-blue">AI Personalized For You</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-widest text-stone-500">Trending Now</h4>
                <div className="space-y-3">
                  {recommendations.trending.map((t: any, i: number) => (
                    <div key={i} className="p-4 bg-white rounded-xl shadow-sm border border-stone-100">
                      <p className="font-bold text-sm">{t.topic}</p>
                      <p className="text-xs text-stone-500 mt-1">{t.description}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-widest text-stone-500">Recommended Destinations</h4>
                <div className="space-y-3">
                  {recommendations.recommendations.map((r: any, i: number) => (
                    <div key={i} className="p-4 bg-white rounded-xl shadow-sm border border-stone-100 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-sm">{r.name}</p>
                        <p className="text-[10px] text-stone-400 mt-0.5">{r.reason}</p>
                      </div>
                      <div className="text-nepal-red font-mono text-xs font-bold">{r.matchScore}% Match</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-serif">Featured Destinations</h3>
          <Button variant="ghost" className="text-xs uppercase tracking-widest font-bold text-stone-400">View All</Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DestinationCard 
            image="https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000&auto=format&fit=crop" 
            title="Everest Base Camp" 
            loc="Solukhumbu"
            tag="Adventure"
          />
          <DestinationCard 
            image="https://images.unsplash.com/photo-1542310503-62580a80e32b?q=80&w=1000&auto=format&fit=crop" 
            title="Pashupatinath" 
            loc="Kathmandu"
            tag="Heritage"
          />
          <DestinationCard 
            image="https://images.unsplash.com/photo-1590487930968-3f8d38827f31?q=80&w=1000&auto=format&fit=crop" 
            title="Phewa Lake" 
            loc="Pokhara" 
            tag="Leisure"
          />
        </div>
      </section>

      <section className="bg-stone-900 rounded-3xl p-12 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-30 bg-cover bg-center" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000")' }} />
        <div className="relative z-10 max-w-xl space-y-6">
          <h3 className="text-3xl font-serif">Share Your Story</h3>
          <p className="text-stone-400">Upload your photos and reviews to help other adventurers find their way.</p>
          <div className="flex gap-4">
            <Button className="bg-white text-stone-900 border-none px-8 flex items-center gap-2">
              <Camera className="w-4 h-4" /> Upload Experience
            </Button>
            <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">Browse Feed</Button>
          </div>
        </div>
      </section>
    </div>
  );
}

function DestinationCard({ image, title, loc, tag }: any) {
  return (
    <Card className="group cursor-pointer border-none shadow-sm h-[400px] relative overflow-hidden flex flex-col justify-end">
      <img src={image} alt={title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
      <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-stone-900/10 to-transparent" />
      <div className="relative p-6 space-y-2">
        <span className="text-[9px] uppercase font-bold tracking-[0.2em] px-2 py-1 bg-stone-50 text-stone-900 rounded inline-block">{tag}</span>
        <h4 className="text-2xl font-serif text-white">{title}</h4>
        <div className="flex items-center gap-1 text-stone-300 text-xs">
          <MapPin className="w-3 h-3" /> {loc}, Nepal
        </div>
        <div className="pt-4 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0 transition-transform">
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
            <span className="text-xs text-white">4.9 (1.2k reviews)</span>
          </div>
          <Plus className="w-5 h-5 text-white" />
        </div>
      </div>
    </Card>
  );
}

function VehiclesView() {
  const vehicles = [
    { type: '4x4 SUV', model: 'Toyota Land Cruiser', price: 120, status: 'Available' },
    { type: 'Adventure Bike', model: 'Royal Enfield Himalayan', price: 45, status: 'Available' },
    { type: 'Compact Car', model: 'Suzuki Swift', price: 35, status: 'Booked' },
    { type: 'VIP Van', model: 'Hyundai H1', price: 90, status: 'Available' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <h2 className="text-4xl font-serif">Vehicle Rentals</h2>
        <p className="text-stone-500 text-sm">Reliable transport for the rugged roads of Nepal.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {vehicles.map((v, i) => (
          <Card key={i} className="p-6 space-y-4">
            <div className="flex justify-between items-start">
              <Car className="w-8 h-8 text-stone-200" />
              <span className={cn(
                "text-[9px] uppercase font-bold px-2 py-1 rounded",
                v.status === 'Available' ? "bg-green-100 text-green-700" : "bg-stone-100 text-stone-500"
              )}>
                {v.status}
              </span>
            </div>
            <div>
              <h4 className="font-bold text-stone-500 text-[10px] uppercase tracking-widest uppercase">{v.type}</h4>
              <p className="font-serif text-lg">{v.model}</p>
            </div>
            <div className="flex justify-between items-center pt-4 border-t border-stone-100">
              <span className="text-stone-900 font-bold font-serif">${v.price}<span className="text-xs text-stone-400 font-sans">/day</span></span>
              <Button variant="ghost" disabled={v.status !== 'Available'} className="text-xs">Rent Now</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function BookingsView() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newBooking, setNewBooking] = useState({ type: 'Hotel', title: '', detail: '', date: '' });

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(collection(db, "bookings")); // In real app, filter by userId
    const unsub = onSnapshot(q, (snap) => {
      setBookings(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return unsub;
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "bookings"), {
        ...newBooking,
        userId: auth.currentUser?.uid,
        createdAt: new Date().toISOString()
      });
      setShowAdd(false);
      setNewBooking({ type: 'Hotel', title: '', detail: '', date: '' });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, "bookings");
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-4xl font-serif">Centralized Hub</h2>
        <Button onClick={() => setShowAdd(!showAdd)} className="gap-2">
          <Plus className="w-4 h-4" /> Add Booking
        </Button>
      </div>

      <AnimatePresence>
        {showAdd && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
            <Card className="p-6 mb-8 bg-stone-50 border-nepal-red/20">
              <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <select 
                  className="px-4 py-2 rounded-lg border border-stone-200 text-sm"
                  value={newBooking.type}
                  onChange={(e) => setNewBooking({...newBooking, type: e.target.value})}
                >
                  <option>Hotel</option>
                  <option>Flight</option>
                  <option>Vehicle</option>
                </select>
                <Input placeholder="Location / Flight Number" value={newBooking.title} onChange={(e: any) => setNewBooking({...newBooking, title: e.target.value})} required />
                <Input placeholder="Details (Room type, Class)" value={newBooking.detail} onChange={(e: any) => setNewBooking({...newBooking, detail: e.target.value})} />
                <div className="flex gap-2">
                  <Input type="date" value={newBooking.date} onChange={(e: any) => setNewBooking({...newBooking, date: e.target.value})} required />
                  <Button type="submit">Save</Button>
                </div>
              </form>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {bookings.length === 0 ? (
          <p className="text-stone-400 italic">No confirmed bookings found. Try adding one manually or connecting your email.</p>
        ) : (
          bookings.map((booking) => (
            <BookingCard 
              key={booking.id}
              icon={booking.type === 'Hotel' ? <Hotel /> : (booking.type === 'Flight' ? <Plane /> : <Car />)} 
              type={booking.type} 
              title={booking.title} 
              detail={booking.detail} 
              date={booking.date} 
              id={booking.id.slice(0, 6)}
            />
          ))
        )}
      </div>
    </div>
  );
}

function BookingCard({ icon, type, title, detail, date, id }: any) {
  return (
    <Card className="p-6 flex gap-6 items-start">
      <div className="p-4 bg-stone-100 rounded-2xl text-stone-500">
        {icon}
      </div>
      <div className="flex-grow space-y-2">
        <div className="flex justify-between">
          <span className="text-[10px] uppercase font-bold text-nepal-red tracking-widest">{type}</span>
          <span className="text-[9px] font-mono text-stone-400"># {id}</span>
        </div>
        <h4 className="text-xl font-serif">{title}</h4>
        <p className="text-xs text-stone-500">{detail}</p>
        <div className="pt-4 flex items-center justify-between">
          <span className="text-xs font-bold text-stone-800">{date}</span>
          <Button variant="outline" className="text-xs">View Ticket</Button>
        </div>
      </div>
    </Card>
  );
}
