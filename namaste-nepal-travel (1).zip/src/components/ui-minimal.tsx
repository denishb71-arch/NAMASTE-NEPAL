import { ReactNode } from "react";
import { cn } from "../lib/utils";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden", className)}>
      {children}
    </div>
  );
}

export function Button({ 
  children, 
  className, 
  variant = 'primary',
  ...props 
}: { 
  children: ReactNode; 
  className?: string; 
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline';
  [key: string]: any;
}) {
  const variants = {
    primary: "bg-nepal-red text-white hover:bg-stone-800 shadow-md",
    secondary: "bg-nepal-blue text-white hover:bg-nepal-blue/90",
    outline: "border border-stone-300 hover:bg-stone-50 text-stone-700",
    ghost: "hover:bg-stone-100 text-stone-600"
  };

  return (
    <button 
      className={cn(
        "px-6 py-2.5 rounded-full text-sm font-medium transition-all flex items-center justify-center gap-2",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function Input({ className, ...props }: { className?: string; [key: string]: any }) {
  return (
    <input 
      className={cn(
        "w-full px-4 py-2 rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-nepal-red/20 focus:border-nepal-red transition-all text-sm",
        className
      )}
      {...props}
    />
  );
}
