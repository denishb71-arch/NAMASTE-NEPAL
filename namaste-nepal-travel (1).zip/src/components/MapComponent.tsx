import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { Card } from "./ui-minimal";
import { Navigation, Map as MapIcon, Satellite } from "lucide-react";

// Fix for default marker icons in React Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Location {
  lat: number;
  lng: number;
  name: string;
}

interface MapProps {
  currentLocation?: Location;
  destination?: Location;
  viewMode?: 'street' | 'satellite';
  showDirections?: boolean;
}

function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, 13);
  }, [center]);
  return null;
}

const mockDirections = [
  { action: "Head north on Durbar Marg", dist: "450m" },
  { action: "Turn right onto Tridevi Sadak", dist: "1.2km" },
  { action: "At the roundabout, take the 2nd exit", dist: "800m" },
  { action: "Continue straight onto Lazimpat Rd", dist: "2.5km" },
  { action: "Your destination is on the left", dist: "100m" },
];

export function MapComponent({ currentLocation, destination, viewMode = 'street', showDirections = true }: MapProps) {
  const [mode, setMode] = useState(viewMode);
  const [navStep, setNavStep] = useState(0);
  const defaultCenter: [number, number] = [27.7172, 85.3240]; // Kathmandu

  useEffect(() => {
    if (showDirections) {
      const interval = setInterval(() => {
        setNavStep((prev) => (prev + 1) % mockDirections.length);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [showDirections]);

  const satelliteLayer = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
  const streetLayer = "https://{s}.tile.openstreetmap.org/{z}/{y}/{x}.png";

  return (
    <Card className="relative w-full h-[400px] overflow-hidden rounded-2xl shadow-xl border-none">
      <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
        <button 
          onClick={() => setMode(mode === 'street' ? 'satellite' : 'street')}
          className="p-3 bg-white hover:bg-stone-100 text-stone-900 rounded-full shadow-lg transition-all"
        >
          {mode === 'street' ? <Satellite className="w-5 h-5" /> : <MapIcon className="w-5 h-5" />}
        </button>
      </div>

      <MapContainer 
        center={currentLocation ? [currentLocation.lat, currentLocation.lng] : defaultCenter} 
        zoom={13} 
        scrollWheelZoom={false}
        className="w-full h-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url={mode === 'satellite' ? satelliteLayer : streetLayer}
        />
        
        {currentLocation && (
          <Marker position={[currentLocation.lat, currentLocation.lng]}>
            <Popup>
              <div className="text-xs">
                <strong>Current Position</strong><br />
                {currentLocation.name}
              </div>
            </Popup>
          </Marker>
        )}

        {destination && (
          <Marker position={[destination.lat, destination.lng]}>
            <Popup>
              <div className="text-xs">
                <strong>Destination</strong><br />
                {destination.name}
              </div>
            </Popup>
          </Marker>
        )}

        {currentLocation && destination && (
          <Polyline 
            positions={[
              [currentLocation.lat, currentLocation.lng],
              [destination.lat, destination.lng]
            ]}
            color="#DC143C"
            weight={3}
            dashArray="5, 10"
          />
        )}
        
        {(currentLocation || destination) && (
          <MapUpdater center={currentLocation ? [currentLocation.lat, currentLocation.lng] : [destination!.lat, destination!.lng]} />
        )}
      </MapContainer>

      <div className="absolute bottom-4 left-4 right-4 z-[1000] flex flex-col gap-2 pointer-events-none">
        {showDirections && (
          <div className="glass px-6 py-4 rounded-2xl flex items-center gap-4 animate-in slide-in-from-bottom-2 duration-500 pointer-events-auto">
            <div className="p-3 bg-nepal-red rounded-xl text-white">
              <Navigation className="w-6 h-6" />
            </div>
            <div className="flex-grow">
              <p className="text-xs uppercase tracking-widest text-stone-500 font-bold">Directions</p>
              <p className="text-lg font-serif leading-tight">{mockDirections[navStep].action}</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-serif text-nepal-blue">{mockDirections[navStep].dist}</p>
              <p className="text-[10px] text-stone-400 font-bold uppercase">Next</p>
            </div>
          </div>
        )}

        <div className="glass px-4 py-2 rounded-lg flex items-center gap-4 w-fit pointer-events-auto">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-widest text-stone-500 font-bold">Route Efficiency</span>
            <span className="text-sm font-serif text-nepal-blue">GPS Active - Road Conditions Normal</span>
          </div>
          <Navigation className="w-5 h-5 text-nepal-red animate-pulse" />
        </div>
      </div>
    </Card>
  );
}
