import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card } from './ui-minimal';
import { Activity, Heart, TrendingUp, Anchor } from 'lucide-react';
import { motion } from 'motion/react';

const data = [
  { day: 'Mon', altitude: 1350, heartRate: 72, steps: 8400 },
  { day: 'Tue', altitude: 2800, heartRate: 85, steps: 12000 },
  { day: 'Wed', altitude: 3440, heartRate: 92, steps: 15600 },
  { day: 'Thu', altitude: 4130, heartRate: 98, steps: 9500 },
  { day: 'Fri', altitude: 3800, heartRate: 88, steps: 7200 },
];

export function HealthDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <HealthStatCard 
          icon={<Heart className="text-nepal-red" />} 
          label="Avg Heart Rate" 
          value="87 bpm" 
          trend="+5%" 
        />
        <HealthStatCard 
          icon={<TrendingUp className="text-green-600" />} 
          label="Steps Today" 
          value="12,450" 
          trend="Target reached" 
        />
        <HealthStatCard 
          icon={<Anchor className="text-nepal-blue" />} 
          label="Current Altitude" 
          value="3,440 m" 
          trend="Acclimatizing" 
        />
        <HealthStatCard 
          icon={<Activity className="text-orange-500" />} 
          label="Oxygen Level" 
          value="94%" 
          trend="Stable" 
        />
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-serif mb-6 flex items-center gap-2">
          <Activity className="w-5 h-5 text-nepal-red" />
          Trek Performance & Biometrics
        </h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#888' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#888' }} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Line 
                type="monotone" 
                dataKey="altitude" 
                stroke="#003893" 
                strokeWidth={3} 
                dot={{ r: 4, fill: '#003893' }}
                activeDot={{ r: 8 }}
              />
              <Line 
                type="monotone" 
                dataKey="heartRate" 
                stroke="#DC143C" 
                strokeWidth={3}
                dot={{ r: 4, fill: '#DC143C' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 flex gap-6 justify-center">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-nepal-blue" />
            <span className="text-xs text-stone-500">Altitude (m)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-nepal-red" />
            <span className="text-xs text-stone-500">Heart Rate (bpm)</span>
          </div>
        </div>
      </Card>
    </div>
  );
}

function HealthStatCard({ icon, label, value, trend }: any) {
  return (
    <motion.div whileHover={{ y: -5 }}>
      <Card className="p-5 flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-[10px] uppercase tracking-widest text-stone-500 font-bold">{label}</p>
          <p className="text-2xl font-serif">{value}</p>
          <p className="text-[10px] text-stone-400">{trend}</p>
        </div>
        <div className="p-3 bg-stone-50 rounded-xl">{icon}</div>
      </Card>
    </motion.div>
  );
}
