import { motion } from "motion/react";
import { Mountain, MapPin, Loader2 } from "lucide-react";

export function LoadingScreen() {
  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-stone-900 text-white overflow-hidden"
    >
      {/* Background Image Placeholder */}
      <div 
        className="absolute inset-0 opacity-40 bg-cover bg-center grayscale shadow-inner"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=2000&auto=format&fit=crop")' }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-transparent to-stone-900" />
      </div>

      <div className="relative z-10 flex flex-col items-center gap-6 text-center px-4">
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        >
          <Mountain className="w-20 h-20 text-nepal-red" />
        </motion.div>

        <div className="space-y-2">
          <h1 className="text-5xl font-serif font-light tracking-widest uppercase">Namaste Nepal</h1>
          <p className="text-stone-400 font-sans tracking-widest text-xs uppercase">Your Himalayan Journey Starts Here</p>
        </div>

        <div className="mt-8 flex items-center gap-3 text-stone-500">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm font-mono tracking-tighter">Initializing trip systems...</span>
        </div>
      </div>

      {/* Decorative Heritage Element */}
      <div className="absolute bottom-12 flex gap-12 opacity-20">
        <MapPin className="w-8 h-8" />
        <Mountain className="w-8 h-8" />
        <MapPin className="w-8 h-8" />
      </div>
    </motion.div>
  );
}
