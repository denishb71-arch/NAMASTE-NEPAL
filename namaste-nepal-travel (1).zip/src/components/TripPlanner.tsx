import { useState } from "react";
import { planTrip } from "../services/geminiService";
import { Button, Input, Card } from "./ui-minimal";
import { Sparkles, Calendar, MapPin, DollarSign, HeartPulse, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export function TripPlanner() {
  const [preferences, setPreferences] = useState("");
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<any>(null);

  const handlePlan = async () => {
    if (!preferences) return;
    setLoading(true);
    try {
      const result = await planTrip(preferences);
      setPlan(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <Card className="p-8 border-none shadow-xl bg-stone-900 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 p-8 opacity-20">
          <Sparkles className="w-24 h-24" />
        </div>
        
        <div className="relative z-10 space-y-6">
          <div className="space-y-2">
            <h2 className="text-3xl font-serif">AI Travel Designer</h2>
            <p className="text-stone-400 text-sm">Tell us your vibes—mountains, culture, or adventure—and we'll build your dream Nepal itinerary.</p>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <Input 
              placeholder="e.g. 10 days trek in Annapurna with luxury stays and cultural focus..." 
              className="bg-white/10 border-white/10 text-white placeholder:text-stone-500 flex-grow"
              value={preferences}
              onChange={(e: any) => setPreferences(e.target.value)}
            />
            <Button onClick={handlePlan} disabled={loading} className="whitespace-nowrap px-8">
              {loading ? <Loader2 className="animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Generate Plan
            </Button>
          </div>
        </div>
      </Card>

      <AnimatePresence>
        {plan && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            <div className="lg:col-span-2 space-y-6">
              <Card className="p-6">
                <div className="flex justify-between items-start mb-6">
                  <h3 className="text-2xl font-serif">{plan.title}</h3>
                  <div className="flex items-center gap-2 text-stone-500 font-mono text-xs">
                    <Calendar className="w-4 h-4" />
                    Customized Itinerary
                  </div>
                </div>
                
                <div className="space-y-8">
                  {plan.itinerary.map((day: any, i: number) => (
                    <div key={i} className="relative pl-8 border-l border-stone-200 py-1">
                      <div className="absolute -left-[5px] top-2 w-2 h-2 rounded-full bg-nepal-red" />
                      <div className="space-y-2">
                        <span className="text-[10px] uppercase tracking-widest text-nepal-red font-bold">Day {day.day}</span>
                        <h4 className="text-lg font-serif">{day.location}</h4>
                        <ul className="text-sm text-stone-600 list-disc list-inside space-y-1">
                          {day.activities.map((act: string, j: number) => (
                            <li key={j}>{act}</li>
                          ))}
                        </ul>
                        <div className="mt-3 flex items-start gap-2 bg-stone-50 p-3 rounded-lg text-xs italic text-stone-500">
                          <HeartPulse className="w-3 h-3 text-nepal-blue shrink-0 mt-0.5" />
                          <span>Health Tip: {day.healthTips}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="p-6">
                <h4 className="text-[10px] uppercase tracking-widest text-stone-500 font-bold mb-4">Financial Overview</h4>
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-stone-500 text-sm">Estimated Budget</span>
                    <span className="text-2xl font-serif text-nepal-blue">{plan.currency} {plan.estimatedBudget}</span>
                  </div>
                  <div className="pt-4 border-t border-stone-100 flex items-center justify-between text-xs text-stone-400">
                    <div className="flex items-center gap-1"><DollarSign className="w-3 h-3" /> Flight & Transport</div>
                    <span>40%</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-stone-400">
                    <div className="flex items-center gap-1"><MapPin className="w-3 h-3" /> Accommodations</div>
                    <span>35%</span>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-stone-50 border-none">
                <h4 className="text-[10px] uppercase tracking-widest text-stone-500 font-bold mb-3">AI Recommendations</h4>
                <p className="text-sm text-stone-600 leading-relaxed italic">
                  "{plan.summary}"
                </p>
                <Button variant="outline" className="w-full mt-6 bg-white">Save Plan to Dashboard</Button>
              </Card>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
