import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Mock Currency Conversion API
  app.get("/api/convert", (req, res) => {
    const { from = "USD", to = "NPR", amount = 1 } = req.query;
    // Real-world: Use an exchange rate API
    const rates: Record<string, number> = {
      "USD-NPR": 133.50,
      "EUR-NPR": 144.20,
      "GBP-NPR": 168.10,
      "INR-NPR": 1.60
    };
    const key = `${from}-${to}`;
    const rate = rates[key] || 1;
    res.json({ result: Number(amount) * rate, rate });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
