import React from 'react';
import { motion } from 'motion/react';
import { Mountain, Compass, MapPin, ShieldCheck, Star, Globe, Sparkles, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="w-full bg-dark-bg">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center">
          <div className="absolute inset-0 bg-dark-bg/60 backdrop-blur-[1px]" />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-bg via-transparent to-dark-bg/20" />
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-amber-accent font-serif tracking-[0.3em] uppercase text-xs mb-4 block">Authentic Himalayan Expeditions</span>
            <h1 className="font-serif text-5xl md:text-8xl font-bold text-white mb-6 tracking-tight leading-none">
              Embrace The <br /> <span className="text-amber-accent italic font-light">Mystical peaks</span>
            </h1>
            <p className="text-lg text-slate-400 mb-10 font-light max-w-2xl mx-auto leading-relaxed">
              Experience the spiritual heart of the Himalayas. From sacred temples to the world's highest summits, your gateway to the divine awaits.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link to="/treks" className="bg-amber-accent text-black px-10 py-4 rounded-full font-bold text-sm tracking-widest uppercase hover:bg-white transition-all shadow-2xl shadow-amber-accent/20">
                Explore Routes
              </Link>
              <Link to="/about" className="bg-white/5 backdrop-blur-md text-white border border-slate-700 px-10 py-4 rounded-full font-bold text-sm tracking-widest uppercase hover:bg-white/10 transition-all">
                Cultural Heritage
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-32 px-4 bg-dark-surface border-y border-slate-800/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-24 items-center">
            <div>
              <span className="text-amber-accent font-serif tracking-widest uppercase text-xs block mb-6">Discover the Land of Gods</span>
              <h2 className="font-serif text-4xl md:text-6xl font-bold mb-8 text-white leading-tight">
                Where Heaven <br /> Touches Earth
              </h2>
              <p className="text-slate-400 text-lg mb-12 leading-relaxed font-light">
                Nepal is not just a destination; it's a spiritual experience. Home to 8 of the world's 14 highest peaks and thousands of years of rich religious history, every step you take is a story of resilience and peace.
              </p>
              <div className="grid grid-cols-2 gap-12">
                <div className="amber-accent">
                  <h4 className="font-serif font-bold text-3xl mb-1 text-white">8,848m</h4>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Mt. Everest Summit</p>
                </div>
                <div className="amber-accent border-nepal-blue">
                   <h4 className="font-serif font-bold text-3xl mb-1 text-white">5,000+</h4>
                   <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Ancient Temples</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
               <div className="space-y-6">
                 <div className="aspect-[3/4] bg-slate-900 rounded-[2rem] overflow-hidden shadow-2xl border border-slate-800/50">
                    <img src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000&auto=format&fit=crop" alt="Stupa" className="w-full h-full object-cover opacity-80" />
                 </div>
                 <div className="aspect-square bg-slate-900 rounded-[2rem] overflow-hidden shadow-2xl border border-slate-800/50">
                    <img src="https://images.unsplash.com/photo-1582294125301-443be1297eef?q=80&w=1000&auto=format&fit=crop" alt="Monks" className="w-full h-full object-cover opacity-80" />
                 </div>
               </div>
               <div className="pt-16 space-y-6">
                 <div className="aspect-square bg-slate-900 rounded-[2rem] overflow-hidden shadow-2xl border border-slate-800/50">
                    <img src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1000&auto=format&fit=crop" alt="Himalayas" className="w-full h-full object-cover opacity-80" />
                 </div>
                 <div className="aspect-[3/4] bg-slate-900 rounded-[2rem] overflow-hidden shadow-2xl border border-slate-800/50">
                     <img src="https://images.unsplash.com/photo-1518005020250-6eb5f382f602?q=80&w=1000&auto=format&fit=crop" alt="Trekker" className="w-full h-full object-cover opacity-80" />
                 </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-32 bg-dark-bg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-white">Start Your Expedition</h2>
            <p className="text-slate-500 font-light max-w-xl mx-auto">Everything you need for your Nepalese adventure, from high-altitude planning to local cultural immersion.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Mountain, title: "Trekking Routes", desc: "From Annapurna to Everest, find the perfect path for your level.", link: "/treks" },
              { icon: Compass, title: "Expert Guides", desc: "Connect with certified local Sherpas and professional guides.", link: "/guides" },
              { icon: MapPin, title: "Hotel Booking", desc: "Find comfortable stays from luxury hotels to authentic tea houses.", link: "/hotels" },
              { icon: Sparkles, title: "AI Trip Architect", desc: "Neural-powered custom itinerary generation for any budget.", link: "/ai-planner" },
              { icon: Mountain, title: "Sherpa Toolkit", desc: "Essential mountain weather, cultural guides, and utility tools.", link: "/toolkit" },
              { icon: AlertCircle, title: "Emergency Responder", desc: "1-tap access to local authorities and personal safety contacts.", link: "/emergency" },
              { icon: ShieldCheck, title: "Secure Booking", desc: "Protected payments via Bank, eSewa, or Khalti.", link: "/booking/:id" },
              { icon: Star, title: "User Reviews", desc: "Trusted ratings from a global community of adventurers.", link: "/treks" },
              { icon: Globe, title: "Local Agencies", desc: "Book directly with registered Nepalese travel agencies.", link: "/agencies" },
            ].map((f, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -10, borderColor: 'rgba(245, 158, 11, 0.3)' }}
                className="bg-dark-card p-10 rounded-[2.5rem] border border-slate-800/50 transition-all hover:shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
              >
                <div className="w-14 h-14 bg-amber-accent/10 rounded-2xl flex items-center justify-center mb-8">
                  <f.icon className="w-7 h-7 text-amber-accent" />
                </div>
                <h3 className="font-serif font-bold text-2xl mb-4 text-white">{f.title}</h3>
                <p className="text-slate-400 mb-8 font-light leading-relaxed">{f.desc}</p>
                <Link to={f.link} className="text-amber-accent font-bold text-[10px] uppercase tracking-[0.2em] hover:text-white transition-colors">See Details →</Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
