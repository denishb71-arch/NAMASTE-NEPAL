import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Calendar, CreditCard, User, Mail, ShieldCheck, MapPin } from 'lucide-react';
import { useAuth } from '../lib/AuthContext';

const Booking = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    date: '',
    guests: 1,
    paymentMethod: 'esewa'
  });

  const handleBooking = async () => {
    // Logic for Firestore booking creation
    alert('Booking initiated! Redirecting to payment portal...');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-slate-50 py-24 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-[2.5rem] shadow-xl overflow-hidden border border-slate-100">
          <div className="bg-slate-900 p-8 text-white flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold font-display">Trek Reservation</h1>
              <p className="text-slate-400 text-sm">Review details and secure your journey</p>
            </div>
            <div className="w-12 h-12 bg-nepal-red rounded-2xl flex items-center justify-center">
              <Calendar className="w-6 h-6" />
            </div>
          </div>

          <div className="p-8">
            {/* Steps indicator */}
            <div className="flex items-center justify-center space-x-4 mb-12">
               {[1, 2, 3].map(s => (
                 <div key={s} className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${step >= s ? 'bg-nepal-red text-white' : 'bg-slate-100 text-slate-400'}`}>
                    {s}
                 </div>
               ))}
            </div>

            {step === 1 && (
              <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="space-y-6">
                <h3 className="font-bold text-xl mb-6">Experience Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-2">
                     <label className="text-xs font-bold uppercase tracking-widest text-slate-500">Pick a Date</label>
                     <div className="relative">
                        <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input 
                           type="date" 
                           className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-nepal-red/20 outline-none"
                           onChange={(e) => setFormData({...formData, date: e.target.value})}
                        />
                     </div>
                   </div>
                   <div className="space-y-2">
                     <label className="text-xs font-bold uppercase tracking-widest text-slate-500">Number of Guests</label>
                     <div className="relative">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input 
                           type="number" 
                           min="1"
                           value={formData.guests}
                           className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-nepal-red/20 outline-none"
                           onChange={(e) => setFormData({...formData, guests: parseInt(e.target.value)})}
                        />
                     </div>
                   </div>
                </div>
                <button 
                  onClick={() => setStep(2)}
                  className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-nepal-red transition-all"
                >
                  Continue to Contact
                </button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="space-y-6">
                <h3 className="font-bold text-xl mb-6">Contact Information</h3>
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 text-blue-800 text-sm flex items-start space-x-3">
                   <ShieldCheck className="w-5 h-5 mt-0.5" />
                   <p>Your information is secured. We will send the permit and route details to your verified email.</p>
                </div>
                <div className="space-y-4">
                   <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Full Name"
                        disabled
                        value={user?.displayName || ''}
                        className="w-full pl-12 pr-4 py-3 bg-slate-100 border border-slate-200 rounded-xl cursor-not-allowed"
                      />
                   </div>
                   <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="email" 
                        placeholder="Email Address"
                        disabled
                        value={user?.email || ''}
                        className="w-full pl-12 pr-4 py-3 bg-slate-100 border border-slate-200 rounded-xl cursor-not-allowed"
                      />
                   </div>
                </div>
                <div className="flex gap-4">
                  <button onClick={() => setStep(1)} className="flex-1 bg-slate-100 text-slate-600 py-4 rounded-xl font-bold">Back</button>
                  <button onClick={() => setStep(3)} className="flex-1 bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-nepal-red">Next</button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="space-y-6">
                <h3 className="font-bold text-xl mb-6">Payment Method</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                   {['esewa', 'khalti', 'bank'].map(method => (
                     <button
                        key={method}
                        onClick={() => setFormData({...formData, paymentMethod: method})}
                        className={`p-6 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${formData.paymentMethod === method ? 'border-nepal-red bg-nepal-red/5' : 'border-slate-100 hover:border-slate-200'}`}
                     >
                        <CreditCard className="w-6 h-6" />
                        <span className="text-xs font-bold uppercase">{method}</span>
                     </button>
                   ))}
                </div>
                <div className="p-6 bg-slate-900 rounded-2xl text-white">
                   <div className="flex justify-between mb-4">
                      <span className="text-slate-400">Total Amount</span>
                      <span className="font-bold text-xl">$XXX.00</span>
                   </div>
                   <button 
                     onClick={handleBooking}
                     className="w-full bg-nepal-red text-white py-4 rounded-xl font-bold hover:bg-white hover:text-nepal-red transition-all"
                   >
                     Complete Reservation
                   </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Booking;
