import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, Shield, LifeBuoy, HeartPulse, Plus, X, Trash2, Send, AlertTriangle, Building, MapPin } from 'lucide-react';
import { useAuth } from '../lib/AuthContext';
import { db } from '../lib/firebase';
import { collection, addDoc, deleteDoc, doc, onSnapshot, query, serverTimestamp } from 'firebase/firestore';
import { EmergencyContact } from '../types';

const Emergency = () => {
  const { user } = useAuth();
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '', relationship: '' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'users', user.uid, 'emergencyContacts'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const contactsData: EmergencyContact[] = [];
      snapshot.forEach((doc) => {
        contactsData.push({ id: doc.id, ...doc.data() } as EmergencyContact);
      });
      setContacts(contactsData);
    });

    return () => unsubscribe();
  }, [user]);

  const handleAddContact = async () => {
    if (!user || !newContact.name || !newContact.phone) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'users', user.uid, 'emergencyContacts'), {
        userId: user.uid,
        name: newContact.name,
        phone: newContact.phone,
        relationship: newContact.relationship,
        createdAt: serverTimestamp()
      });
      setNewContact({ name: '', phone: '', relationship: '' });
      setIsAdding(false);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteContact = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'emergencyContacts', id));
    } catch (error) {
      console.error(error);
    }
  };

  const officialNumbers = [
    { name: 'Nepal Police', phone: '100', icon: Shield, color: 'bg-blue-500/10 text-blue-500', desc: 'General emergencies & safety' },
    { name: 'Tourist Police', phone: '1144', icon: LifeBuoy, color: 'bg-emerald-500/10 text-emerald-500', desc: 'Dedicated support for travelers' },
    { name: 'Medical / Ambulance', phone: '102', icon: HeartPulse, color: 'bg-red-500/10 text-red-500', desc: 'Emergency medical assistance' },
    { name: 'Himalayan Rescue', phone: '01-4440292', icon: Building, color: 'bg-amber-500/10 text-amber-500', desc: 'High altitude & trek rescue' }
  ];

  return (
    <div className="min-h-screen bg-dark-bg text-slate-200 py-40 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="inline-flex items-center space-x-3 bg-red-500/10 px-6 py-2 rounded-full text-red-500 mb-8 border border-red-500/20"
          >
            <AlertTriangle className="w-5 h-5 animate-pulse" />
            <span className="text-[10px] uppercase font-bold tracking-[0.3em]">Critical Response Protocol</span>
          </motion.div>
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-white mb-8 tracking-tighter leading-none">
            EMERGENCY <span className="text-red-500 italic font-light">RESPONDER</span>
          </h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-light leading-relaxed">
            Immediate access to official Nepalese authorities and your secure personal safety network. 
            Keep your location data enabled for faster response times.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Official Numbers */}
          <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
            {officialNumbers.map((num, i) => (
              <motion.div
                key={num.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="dark-card p-8 group hover:border-red-500/30 transition-all cursor-pointer"
                onClick={() => window.open(`tel:${num.phone}`)}
              >
                <div className={`w-12 h-12 ${num.color} rounded-2xl flex items-center justify-center mb-6 shadow-xl`}>
                  <num.icon className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-white mb-2">{num.name}</h3>
                <p className="text-slate-500 text-xs mb-6 font-light">{num.desc}</p>
                <div className="flex items-center space-x-2 text-white font-black text-2xl group-hover:text-red-500 transition-colors">
                  <Phone className="w-5 h-5" />
                  <span>{num.phone}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Personal Contacts */}
          <div className="lg:col-span-8 space-y-8">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-amber-accent/10 rounded-2xl flex items-center justify-center text-amber-accent shadow-xl border border-amber-accent/20">
                  <LifeBuoy className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-serif text-3xl font-bold text-white">Personal SOS Network</h2>
                  <p className="text-[10px] text-amber-accent font-bold uppercase tracking-widest">Secure cloud-synced contacts</p>
                </div>
              </div>
              <button 
                onClick={() => setIsAdding(!isAdding)}
                className="p-4 bg-slate-800 text-white rounded-2xl hover:bg-amber-accent hover:text-black transition-all flex items-center space-x-2"
              >
                <Plus className="w-5 h-5" />
                <span className="text-[10px] uppercase font-black tracking-widest hidden md:block">Add Contact</span>
              </button>
            </div>

            <AnimatePresence>
              {isAdding && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden mb-12"
                >
                  <div className="dark-card p-10 space-y-8 border-amber-accent/20">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-4">
                        <label className="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Name</label>
                        <input 
                          type="text" 
                          value={newContact.name}
                          onChange={(e) => setNewContact({...newContact, name: e.target.value})}
                          className="w-full bg-dark-bg border border-slate-800 rounded-xl p-4 text-white focus:ring-2 focus:ring-amber-accent/20 outline-none"
                          placeholder="Full Name"
                        />
                      </div>
                      <div className="space-y-4">
                        <label className="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Phone</label>
                        <input 
                          type="text" 
                          value={newContact.phone}
                          onChange={(e) => setNewContact({...newContact, phone: e.target.value})}
                          className="w-full bg-dark-bg border border-slate-800 rounded-xl p-4 text-white focus:ring-2 focus:ring-amber-accent/20 outline-none"
                          placeholder="+000..."
                        />
                      </div>
                      <div className="space-y-4">
                        <label className="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Relation</label>
                        <input 
                          type="text" 
                          value={newContact.relationship}
                          onChange={(e) => setNewContact({...newContact, relationship: e.target.value})}
                          className="w-full bg-dark-bg border border-slate-800 rounded-xl p-4 text-white focus:ring-2 focus:ring-amber-accent/20 outline-none"
                          placeholder="e.g. Family"
                        />
                      </div>
                    </div>
                    <div className="flex space-x-4">
                      <button 
                        onClick={handleAddContact}
                        disabled={loading}
                        className="flex-grow bg-amber-accent text-black py-4 rounded-xl font-black uppercase text-xs tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-amber-accent/10"
                      >
                        {loading ? 'Wait...' : 'Secure Contact'}
                      </button>
                      <button 
                        onClick={() => setIsAdding(false)}
                        className="px-6 bg-slate-800 text-white rounded-xl"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {contacts.length === 0 ? (
                <div className="col-span-2 p-12 bg-dark-card rounded-[2rem] border border-dashed border-slate-800 text-center">
                  <HeartPulse className="w-12 h-12 text-slate-700 mx-auto mb-6" />
                  <h3 className="font-serif text-2xl text-slate-400 font-bold italic">No personal SOS contacts</h3>
                  <p className="text-slate-600 text-sm font-light mt-2">Add family or friends for 1-tap emergency notification.</p>
                </div>
              ) : (
                contacts.map((contact) => (
                  <motion.div
                    key={contact.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="dark-card p-8 flex items-center justify-between group"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-amber-accent border border-slate-700 font-serif font-bold text-xl">
                        {contact.name[0]}
                      </div>
                      <div>
                        <h4 className="text-white font-bold text-lg">{contact.name}</h4>
                        <p className="text-[10px] text-amber-accent font-bold uppercase tracking-widest">{contact.relationship}</p>
                        <p className="text-slate-500 font-mono text-xs mt-1">{contact.phone}</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                       <button 
                         onClick={() => window.open(`tel:${contact.phone}`)}
                         className="p-3 bg-amber-accent text-black rounded-xl hover:bg-white transition-all shadow-lg"
                       >
                         <Phone className="w-4 h-4" />
                       </button>
                       <button 
                         onClick={() => handleDeleteContact(contact.id)}
                         className="p-3 bg-red-500/20 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all"
                       >
                         <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>

          {/* Quick Support Sidebar */}
          <div className="lg:col-span-4 space-y-8">
            <div className="dark-card p-10 bg-red-500/5 border-red-500/10">
               <div className="flex items-center space-x-4 mb-8">
                  <div className="w-12 h-12 bg-red-500/20 text-red-500 rounded-2xl flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-serif text-2xl font-bold text-white italic">SOS Pulse</h3>
                    <p className="text-[10px] text-red-500/70 uppercase font-black tracking-widest">Instant Broadcast</p>
                  </div>
               </div>
               <p className="text-slate-400 text-xs font-light leading-relaxed mb-10">
                 Activate the broadcast to alert all your SOS contacts with your current GPS coordinates. 
                 Requires active data connection and GPS.
               </p>
               <button className="w-full bg-red-500 text-white py-8 rounded-[2rem] font-black uppercase tracking-[0.3em] text-sm shadow-2xl shadow-red-500/20 hover:scale-105 active:scale-95 transition-all">
                 BROADCAST SOS
               </button>
            </div>

            <div className="dark-card p-10">
               <div className="flex items-center space-x-4 mb-8">
                  <div className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center text-amber-accent">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-white">Local Hubs</h3>
               </div>
               <div className="space-y-6">
                  {[
                    { loc: 'Kathmandu', phone: '01-4412748' },
                    { loc: 'Pokhara', phone: '061-462761' },
                    { loc: 'Lukla', phone: '038-540123' },
                    { loc: 'Namche', phone: '038-540056' }
                  ].map(hub => (
                    <div key={hub.loc} className="flex items-center justify-between p-4 bg-dark-bg rounded-2xl border border-slate-800">
                      <span className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">{hub.loc}</span>
                      <span className="text-white font-mono text-xs">{hub.phone}</span>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Emergency;
