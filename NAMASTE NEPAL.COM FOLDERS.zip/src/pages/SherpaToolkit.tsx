import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Languages, Banknote, RefreshCcw, ArrowRightLeft, CloudSun, 
  Wind, Thermometer, Map, BookOpen, Quote, Sparkles, 
  CheckCircle2, AlertCircle, Mountain
} from 'lucide-react';

const SherpaToolkit = () => {
  const [currency, setCurrency] = useState({ amount: 1, from: 'USD', to: 'NPR', result: 133.5 });
  const [translationText, setTranslationText] = useState('');
  const [translationResult, setTranslationResult] = useState('');
  const [activeTab, setActiveTab] = useState<'tools' | 'culture' | 'weather'>('tools');

  const convertCurrency = async () => {
    try {
      const res = await fetch(`/api/convert?amount=${currency.amount}&from=${currency.from}&to=${currency.to}`);
      const data = await res.json();
      setCurrency({ ...currency, result: data.result });
    } catch (error) {
      console.error(error);
    }
  };

  const translateText = () => {
    const dictionary: Record<string, string> = {
      'hello': 'Namaste',
      'thank you': 'Dhanyabaad',
      'water': 'Paani',
      'food': 'Khana',
      'how much': 'Kati ho?',
      'beautiful': 'Ramro',
      'help': 'Guhar',
      'where': 'Kata?',
      'expensive': 'Mahango',
      'cheap': 'Sasto',
      'yes': 'Ho',
      'no': 'Hoina'
    };
    const word = translationText.toLowerCase().trim();
    setTranslationResult(dictionary[word] || "Exploring dialects...");
  };

  const weatherStates = [
    { loc: 'Everest Base Camp', temp: '-12°C', wind: '45 km/h', cond: 'High Winds', icon: Wind },
    { loc: 'Namche Bazaar', temp: '4°C', wind: '12 km/h', cond: 'Light Snow', icon: CloudSun },
    { loc: 'Annapurna Base Camp', temp: '-5°C', wind: '20 km/h', cond: 'Clear Sky', icon: Sparkles },
    { loc: 'Pokhara', temp: '22°C', wind: '5 km/h', cond: 'Sunny', icon: CloudSun }
  ];

  const culturalTips = [
    { title: "The Sacred Left", desc: "Never use your left hand to eat or pass objects. It is considered disrespectful.", type: 'dont' },
    { title: "Namaste Greeting", desc: "Always greet with palms together at chest level. Avoid firm handshakes unless initiated.", type: 'do' },
    { title: "Clockwise Movement", desc: "Always walk around stupas, mani walls, and shrines in a clockwise direction.", type: 'do' },
    { title: "Photography Ethics", desc: "Always ask before taking photos of people or inside temples. Some rituals are private.", type: 'do' },
    { title: "Public Display of Affection", desc: "Avoid hugging or kissing in public, as it is viewed as culturally inappropriate.", type: 'dont' }
  ];

  return (
    <div className="min-h-screen bg-dark-bg text-slate-200 py-40 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="inline-flex items-center space-x-3 bg-amber-accent/10 px-6 py-2 rounded-full text-amber-accent mb-8 border border-amber-accent/20"
          >
            <Mountain className="w-5 h-5" />
            <span className="text-[10px] uppercase font-bold tracking-[0.3em]">Himalayan Intelligence Unit</span>
          </motion.div>
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-white mb-8 tracking-tighter leading-none">
            SHERPA <span className="text-amber-accent italic font-light">TOOLKIT</span>
          </h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-light leading-relaxed">
            Essential utilities for high-altitude navigation, cultural synchronization, and local logistics. 
            Designed for the modern adventurer.
          </p>
        </div>

        {/* Tab Switching */}
        <div className="flex flex-wrap justify-center gap-4 mb-20">
          {[
            { id: 'tools', label: 'Survival Tools', icon: RefreshCcw },
            { id: 'weather', label: 'Mountain Weather', icon: CloudSun },
            { id: 'culture', label: 'Cultural Guide', icon: BookOpen }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-3 px-8 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] border transition-all ${
                activeTab === tab.id 
                  ? 'bg-amber-accent text-black border-amber-accent shadow-xl shadow-amber-accent/10' 
                  : 'bg-dark-card border-slate-800 text-slate-500 hover:border-slate-700'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'tools' && (
            <motion.div
              key="tools"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-12"
            >
              {/* Currency */}
              <div className="dark-card p-12">
                <div className="flex items-center space-x-4 mb-10">
                  <div className="w-12 h-12 bg-amber-accent/10 rounded-2xl flex items-center justify-center text-amber-accent border border-amber-accent/20">
                    <Banknote className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-3xl font-bold text-white italic">Currency Hub</h3>
                </div>
                <div className="space-y-6">
                  <div className="flex space-x-4">
                    <input 
                      type="number" 
                      value={currency.amount}
                      onChange={(e) => setCurrency({...currency, amount: parseFloat(e.target.value)})}
                      className="flex-grow bg-dark-bg border border-slate-800 p-5 rounded-2xl text-white font-serif text-2xl font-bold"
                    />
                    <select 
                      value={currency.from}
                      onChange={(e) => setCurrency({...currency, from: e.target.value})}
                      className="bg-dark-bg border border-slate-800 p-5 rounded-2xl text-slate-400 font-bold uppercase tracking-widest text-xs"
                    >
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                      <option value="GBP">GBP</option>
                    </select>
                  </div>
                  <div className="flex justify-center">
                    <button onClick={convertCurrency} className="p-4 bg-amber-accent text-black rounded-full hover:scale-110 active:scale-95 transition-all">
                      <RefreshCcw className="w-6 h-6" />
                    </button>
                  </div>
                  <div className="bg-dark-bg/50 border-2 border-slate-800 p-8 rounded-[2rem] text-center">
                    <p className="text-[10px] text-slate-600 uppercase font-black tracking-widest mb-2">Estimated Amount</p>
                    <p className="text-white font-serif text-5xl font-bold">
                      {currency.result.toFixed(2)} <span className="text-amber-accent italic font-light">NPR</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Translation */}
              <div className="dark-card p-12">
                <div className="flex items-center space-x-4 mb-10">
                  <div className="w-12 h-12 bg-amber-accent/10 rounded-2xl flex items-center justify-center text-amber-accent border border-amber-accent/20">
                    <Languages className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-3xl font-bold text-white italic">Phrasebook</h3>
                </div>
                <div className="space-y-6">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Type a word in English..."
                      value={translationText}
                      onChange={(e) => setTranslationText(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && translateText()}
                      className="w-full bg-dark-bg border border-slate-800 p-6 rounded-2xl text-white outline-none focus:border-amber-accent/30 transition-all"
                    />
                    <button 
                      onClick={translateText}
                      className="absolute right-3 top-3 p-3 bg-amber-accent text-black rounded-xl hover:bg-white transition-all shadow-xl shadow-amber-accent/20"
                    >
                      <ArrowRightLeft className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-12 bg-dark-surface border border-slate-800 rounded-[3rem] text-center group">
                    <Quote className="w-8 h-8 text-slate-700 mx-auto mb-6 opacity-50" />
                    <p className="text-amber-accent font-serif text-5xl font-bold italic group-hover:scale-110 transition-transform duration-700">
                      {translationResult || '---'}
                    </p>
                    <p className="text-slate-500 text-[10px] mt-6 tracking-[0.3em] font-black uppercase">Mountain Tongue</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'weather' && (
            <motion.div
              key="weather"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            >
              {weatherStates.map((w, i) => (
                <div key={w.loc} className="dark-card p-10 group overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-accent/5 rounded-bl-[4rem] group-hover:bg-amber-accent/10 transition-all duration-700" />
                  <w.icon className="w-10 h-10 text-amber-accent mb-8" />
                  <h4 className="text-[10px] text-slate-500 uppercase tracking-widest font-black mb-2">{w.loc}</h4>
                  <div className="flex items-baseline space-x-2 mb-6">
                    <span className="text-5xl font-serif font-bold text-white">{w.temp}</span>
                    <Thermometer className="w-4 h-4 text-slate-600" />
                  </div>
                  <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest">
                    <span className="text-slate-400">{w.cond}</span>
                    <span className="text-amber-accent">{w.wind}</span>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'culture' && (
            <motion.div
              key="culture"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {culturalTips.map((tip, i) => (
                <div key={tip.title} className="dark-card p-10 flex flex-col justify-between border-slate-800/50">
                  <div>
                    <div className="flex items-center justify-between mb-8">
                       <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tip.type === 'do' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                        {tip.type === 'do' ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
                      </div>
                      <span className={`text-[10px] font-black uppercase tracking-widest ${tip.type === 'do' ? 'text-emerald-500' : 'text-red-500'}`}>
                        {tip.type === 'do' ? 'Best Practice' : 'Avoid This'}
                      </span>
                    </div>
                    <h4 className="font-serif text-2xl font-bold text-white mb-4 italic">{tip.title}</h4>
                    <p className="text-slate-500 text-sm font-light leading-relaxed">{tip.desc}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SherpaToolkit;
