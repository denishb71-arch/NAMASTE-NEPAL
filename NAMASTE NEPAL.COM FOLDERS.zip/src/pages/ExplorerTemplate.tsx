import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Service } from '../types';
import { MapPin, Star, Search, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

const ExplorerTemplate = ({ type, title }: { type: string, title: string }) => {
  const [items, setItems] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      // Mocking for now as database might be empty
      const mocks: Record<string, Service[]> = {
        mountaineering: [
          { id: 'mnt-1', type: 'mountaineering', name: 'Everest Expedition', location: 'Solukhumbu', price: 35000, images: ['https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000'], rating: 5.0, tags: ['Pro', 'Expedition'], description: 'Conquer the roof of the world.', providerId: 'p1', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 50, duration: '60 Days' },
          { id: 'mnt-2', type: 'mountaineering', name: 'Mera Peak Climbing', location: 'Hinku Valley', price: 2500, images: ['https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1000'], rating: 4.8, tags: ['Alpine'], description: 'The highest trekking peak in Nepal.', providerId: 'p2', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 50, duration: '18 Days' },
          { id: 'mnt-3', type: 'mountaineering', name: 'Island Peak Adventure', location: 'Chukhung Valley', price: 2200, images: ['https://images.unsplash.com/photo-1582294125301-443be1297eef?q=80&w=1000'], rating: 4.9, tags: ['Summit', 'Ice'], description: 'A classic introduction to Himalayan climbing.', providerId: 'p15', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 30, duration: '16 Days' }
        ],
        hotel: [
          { id: 'h-1', type: 'hotel', name: 'Everest View Hotel', location: 'Syangboche', price: 250, images: ['https://images.unsplash.com/photo-1518005020250-6eb5f382f602?q=80&w=1000'], rating: 4.9, tags: ['Luxury', 'View'], description: 'World\'s highest luxury hotel.', providerId: 'p3', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 50 },
          { id: 'h-2', type: 'hotel', name: 'Tea House Inn', location: 'Namche Bazaar', price: 40, images: ['https://images.unsplash.com/photo-1582294125301-443be1297eef?q=80&w=1000'], rating: 4.5, tags: ['Authentic'], description: 'Cozy stay with warm local vibes.', providerId: 'p4', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 50 },
          { id: 'h-3', type: 'hotel', name: 'Dwarika\'s Kathmandu', location: 'Kathmandu', price: 350, images: ['https://images.unsplash.com/photo-1551882547-ff43c63fed0c?q=80&w=1000'], rating: 5.0, tags: ['Heritage', 'Eco'], description: 'A living museum of Nepalese architecture.', providerId: 'p16', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 120 }
        ],
        guide: [
          { id: 'g-1', type: 'guide', name: 'Pasang Sherpa', location: 'Solukhumbu', price: 50, images: ['https://images.unsplash.com/photo-1512100356956-c1227c44671e?q=80&w=1000'], rating: 5.0, tags: ['Expert', 'Sherpa'], description: 'Over 10 summits. Expert high-altitude guide.', providerId: 'p5', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 50 },
          { id: 'g-2', type: 'guide', name: 'Ang Rita', location: 'Everest Region', price: 65, images: ['https://images.unsplash.com/photo-1527631746610-bca00a040d60?q=80&w=1000'], rating: 4.9, tags: ['Legend', 'Mountain'], description: 'Specialist in private Everest Base Camp treks.', providerId: 'p17', currency: 'USD', coordinates: { lat: 0, lng: 0 }, reviewCount: 85 }
        ],
        agency: [
          { 
            id: 'ag-1', 
            type: 'agency', 
            name: 'Himalayan Wonders', 
            location: 'Thamel, Kathmandu - Near Garden of Dreams', 
            price: 1200, 
            images: [
              'https://images.unsplash.com/photo-1551882547-ff43c63fed0c?q=80&w=1000',
              'https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000'
            ], 
            rating: 4.9, 
            tags: ['Eco-Friendly', 'Certified'], 
            description: 'Leading adventure agency specializing in sustainable trekking and peak climbing expeditions across the Everest and Annapurna regions. Our office is located in the heart of Thamel, easily accessible for all travelers.', 
            providerId: 'p10', 
            currency: 'USD', 
            coordinates: { lat: 27.7149, lng: 85.3123 }, 
            reviewCount: 450 
          },
          { 
            id: 'ag-2', 
            type: 'agency', 
            name: 'Summit Sherpa Adventures', 
            location: 'Namche Bazaar, Solukhumbu - Main Bazaar Street', 
            price: 1800, 
            images: [
              'https://images.unsplash.com/photo-1527631746610-bca00a040d60?q=80&w=1000',
              'https://images.unsplash.com/photo-1518005020250-6eb5f382f602?q=80&w=1000'
            ], 
            rating: 5.0, 
            tags: ['Local owned', 'Everest Experts'], 
            description: 'Owned and operated by local Sherpas, providing authentic high-altitude support and cultural immersion for international climbers. We offer specialized base camp support and porter services.', 
            providerId: 'p11', 
            currency: 'USD', 
            coordinates: { lat: 27.8069, lng: 86.7140 }, 
            reviewCount: 320 
          },
          { 
            id: 'ag-3', 
            type: 'agency', 
            name: 'Annapurna Eco-Treks', 
            location: 'Lakeside, Pokhara - Ward No. 6', 
            price: 950, 
            images: [
              'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1000',
              'https://images.unsplash.com/photo-1582294125301-443be1297eef?q=80&w=1000'
            ], 
            rating: 4.7, 
            tags: ['Sustainable', 'Pokhara Local'], 
            description: 'Specialists in the Annapurna Circuit and Sanctuary treks. We focus on low-impact tourism and supporting local communities throughout the Western Himalayas.', 
            providerId: 'p12', 
            currency: 'USD', 
            coordinates: { lat: 28.2096, lng: 83.9589 }, 
            reviewCount: 280 
          }
        ]
      };
      setItems(mocks[type] || []);
      setLoading(false);
    };
    fetchData();
  }, [type]);

  return (
    <div className="bg-dark-bg min-h-screen pt-24 pb-24 px-4 font-sans relative overflow-hidden">
      <div className="absolute top-0 -right-64 w-96 h-96 bg-amber-accent/5 rounded-full blur-[120px]" />
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="mb-16 border-l-8 border-amber-accent pl-8">
          <h1 className="text-4xl md:text-6xl font-bold font-serif tracking-tighter text-white">{title}</h1>
          <p className="text-slate-500 mt-2 uppercase tracking-[0.3em] text-[10px] font-bold font-sans">Namaste Nepal Curated Selection</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {items.map(item => (
            <motion.div key={item.id} whileHover={{ y: -10 }} className="dark-card overflow-hidden group">
               <div className="aspect-[4/5] relative overflow-hidden">
                  <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-bg via-transparent to-transparent opacity-80" />
                  <div className="absolute top-6 right-6 bg-dark-bg/80 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center space-x-1 border border-slate-700/50">
                    <Star className="w-3 h-3 text-amber-accent fill-current" />
                    <span className="text-[10px] font-black">{item.rating}</span>
                  </div>
               </div>
               <div className="p-10">
                  <div className="flex items-center space-x-2 text-amber-accent mb-4">
                     <MapPin className="w-4 h-4" />
                     <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.location}</span>
                     {item.duration && (
                       <>
                         <span className="text-slate-700">•</span>
                         <Clock className="w-4 h-4" />
                         <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.duration}</span>
                       </>
                     )}
                  </div>
                  <h3 className="text-3xl font-serif font-bold mb-4 text-white group-hover:text-amber-accent transition-colors leading-tight">{item.name}</h3>
                  <p className="text-slate-500 text-sm font-light leading-relaxed mb-10 line-clamp-2">{item.description}</p>
                  <div className="flex justify-between items-center pt-8 border-t border-slate-800/50">
                     <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-widest mb-1">Starting from</span>
                        <span className="text-2xl font-serif font-bold text-white">${item.price}<span className="text-xs font-normal text-slate-500">/item</span></span>
                     </div>
                     <Link to={`/booking/${item.id}`} className="bg-white text-black px-8 py-4 rounded-full text-xs font-black uppercase tracking-widest hover:bg-amber-accent transition-all shadow-xl">Reserve</Link>
                  </div>
               </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExplorerTemplate;
