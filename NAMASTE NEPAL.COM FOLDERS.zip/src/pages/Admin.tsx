import React, { useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { motion } from 'motion/react';
import { LayoutDashboard, Users, Map, Settings, BarChart3, Plus, Search, Filter, MoreVertical, TrendingUp, DollarSign, Calendar as CalIcon } from 'lucide-react';

const AdminPanel = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (user?.role !== 'admin') {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-slate-500">You do not have administrative privileges.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col p-6 space-y-8 hidden md:flex">
        <div className="font-display font-bold text-xl flex items-center space-x-2">
           <div className="w-8 h-8 bg-nepal-red rounded-lg" />
           <span>NAMASTE <span className="text-nepal-red">HQ</span></span>
        </div>

        <nav className="flex-grow space-y-2">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
            { id: 'users', icon: Users, label: 'Manage Users' },
            { id: 'services', icon: Map, label: 'Trips & Services' },
            { id: 'analytics', icon: BarChart3, label: 'Analytics' },
            { id: 'settings', icon: Settings, label: 'System Settings' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${activeTab === item.id ? 'bg-nepal-red text-white' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 bg-white/5 rounded-2xl">
           <p className="text-[10px] uppercase font-bold text-slate-500 mb-2">Logged in as</p>
           <p className="text-sm font-medium truncate">{user.email}</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-8 overflow-y-auto">
        <header className="flex justify-between items-center mb-12">
           <h1 className="text-3xl font-bold font-display capitalize">{activeTab} Interface</h1>
           <div className="flex items-center space-x-4">
              <button className="p-2 bg-white rounded-xl border border-slate-200"><Search className="w-5 h-5 text-slate-400" /></button>
              <button className="flex items-center space-x-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-bold">
                 <Plus className="w-4 h-4" />
                 <span>Add Service</span>
              </button>
           </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Total Revenue', value: '$45,231', icon: DollarSign, trend: '+12%', color: 'text-emerald-600' },
                { label: 'Active Bookings', value: '1,204', icon: CalIcon, trend: '+5%', color: 'text-blue-600' },
                { label: 'New Users', value: '+54', icon: Users, trend: '+18%', color: 'text-nepal-red' },
                { label: 'Platform Growth', value: '24.5%', icon: TrendingUp, trend: '+2%', color: 'text-amber-600' },
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-slate-50 rounded-2xl">
                       <stat.icon className="w-5 h-5 text-slate-400" />
                    </div>
                    <span className={`text-xs font-bold ${stat.color} bg-current/10 px-2 py-1 rounded-full`}>{stat.trend}</span>
                  </div>
                  <p className="text-slate-400 text-sm mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* List Table Placeholder */}
            <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm">
               <div className="flex justify-between items-center mb-8">
                  <h3 className="font-bold text-xl">Recent Bookings</h3>
                  <button className="text-nepal-red text-sm font-bold hover:underline">View All</button>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-left">
                   <thead>
                     <tr className="border-b border-slate-100 text-xs font-bold uppercase tracking-widest text-slate-400">
                        <th className="pb-4">User</th>
                        <th className="pb-4">Service</th>
                        <th className="pb-4">Date</th>
                        <th className="pb-4">Status</th>
                        <th className="pb-4"></th>
                     </tr>
                   </thead>
                   <tbody className="text-sm">
                     {[1, 2, 3, 4, 5].map(i => (
                       <tr key={i} className="border-b border-slate-50 hover:bg-slate-50 transition-colors group">
                          <td className="py-4">
                             <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 rounded-full bg-slate-200" />
                                <span className="font-medium text-slate-900 truncate max-w-[120px]">User_{i}</span>
                             </div>
                          </td>
                          <td className="py-4">Mount Everest Expedition</td>
                          <td className="py-4">Oct 12, 2026</td>
                          <td className="py-4">
                             <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold uppercase">Confirmed</span>
                          </td>
                          <td className="py-4 text-right">
                             <button className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-white rounded-lg"><MoreVertical className="w-4 h-4 text-slate-400" /></button>
                          </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminPanel;
