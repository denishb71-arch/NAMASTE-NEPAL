import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, where, doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Service, TrekDetail } from '../types';
import { Search, MapPin, Star, Clock, X, ChevronRight, Info, ShieldCheck, ClipboardList, Thermometer, Mountain } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';

const TrekExplorer = () => {
  const [treks, setTreks] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('rating');
  const [durationFilter, setDurationFilter] = useState('all');
  
  const [selectedDetail, setSelectedDetail] = useState<TrekDetail | null>(null);
  const [isDetailLoading, setIsDetailLoading] = useState(false);

  useEffect(() => {
    const fetchTreks = async () => {
      try {
        const q = query(collection(db, 'services'), where('type', '==', 'trek'));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Service));
        
        if (data.length === 0) {
          const mockTreks: Service[] = [
            {
              id: 'ebc-001',
              type: 'trek',
              name: 'Everest Base Camp Trek',
              description: 'The ultimate trekking experience to the base of the world\'s highest peak.',
              location: 'Khumbu Region',
              coordinates: { lat: 27.9881, lng: 86.9250 },
              price: 1500,
              currency: 'USD',
              images: ['https://images.unsplash.com/photo-1533130061792-64b345e4a833?q=80&w=1000&auto=format&fit=crop'],
              providerId: 'sherpa-exp',
              rating: 4.9,
              reviewCount: 1250,
              duration: '14 Days',
              tags: ['Challenging', 'Everest']
            },
            {
              id: 'abc-002',
              type: 'trek',
              name: 'Annapurna Base Camp',
              description: 'A diverse journey through rhododendron forests to a natural amphitheater of peaks.',
              location: 'Annapurna Region',
              coordinates: { lat: 28.5300, lng: 83.8780 },
              price: 900,
              currency: 'USD',
              images: ['https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000&auto=format&fit=crop'],
              providerId: 'trek-nepal',
              rating: 4.8,
              reviewCount: 980,
              duration: '10 Days',
              tags: ['Moderate', 'Annapurna']
            },
            {
              id: 'lms-003',
              type: 'trek',
              name: 'Langtang Valley Trek',
              description: 'The valley of glaciers. A perfect short trek near Kathmandu with stunning views.',
              location: 'Langtang',
              coordinates: { lat: 28.2167, lng: 85.5667 },
              price: 650,
              currency: 'USD',
              images: ['https://images.unsplash.com/photo-1582294125301-443be1297eef?q=80&w=1000&auto=format&fit=crop'],
              providerId: 'himal-guides',
              rating: 4.7,
              reviewCount: 450,
              duration: '07 Days',
              tags: ['Easy-Moderate', 'Glaciers']
            }
          ];
          setTreks(mockTreks);
        } else {
          setTreks(data);
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchTreks();
  }, []);

  const fetchTrekDetail = async (trekId: string) => {
    setIsDetailLoading(true);
    try {
      const docRef = doc(db, 'trekDetails', trekId);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        setSelectedDetail(docSnap.data() as TrekDetail);
      } else {
        // Fallback mock detail based on ID
        const mockDetails: Record<string, TrekDetail> = {
          'ebc-001': {
            id: 'ebc-001',
            difficulty: 'Challenging',
            itinerary: [
              { day: 1, title: 'Kathmandu Arrival', description: 'Briefing and trek preparation.' },
              { day: 2, title: 'Fly to Lukla (2,860m)', description: 'Spectacular flight and trek to Phakding.' },
              { day: 3, title: 'Trek to Namche Bazaar', description: 'Enter Sagarmatha National Park.' },
              { day: 4, title: 'Acclimatization Day', description: 'Explore Namche and view Everest.' },
              { day: 5, title: 'Trek to Tengboche', description: 'Visit the famous monastery.' }
            ],
            permits: ['TIMS Card', 'Sagarmatha National Park Entry', 'Khumbu Pasang Lhamu Rural Municipality Permit'],
            packingList: ['Warm Layers', 'Down Jacket', 'Insulated Boots', 'Sunscreen', 'First Aid Kit'],
            bestTime: ['Oct - Nov', 'Mar - May']
          },
          'abc-002': {
            id: 'abc-002',
            difficulty: 'Moderate',
            itinerary: [
              { day: 1, title: 'Pokhara to Ghandruk', description: 'Beautiful Gurung village.' },
              { day: 2, title: 'Trek to Chhomrong', description: 'Steep steps and mountain views.' },
              { day: 3, title: 'Trek to Himalaya', description: 'Through rhododendron forests.' }
            ],
            permits: ['ACAP Permit', 'TIMS Card'],
            packingList: ['Walking poles', 'Rain gear', 'Light boots', 'Electrolytes'],
            bestTime: ['Sept - Dec', 'Feb - June']
          }
        };
        
        setSelectedDetail(mockDetails[trekId] || {
          id: trekId,
          difficulty: 'Moderate',
          itinerary: [{ day: 1, title: 'Meeting Point', description: 'Start of the adventure.' }],
          permits: ['TIMS Card'],
          packingList: ['Standard gear'],
          bestTime: ['All year']
        });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsDetailLoading(false);
    }
  };

  const filteredTreks = treks.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      t.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDuration = durationFilter === 'all' || t.duration === durationFilter;
    
    return matchesSearch && matchesDuration;
  }).sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    return b.rating - a.rating;
  });

  return (
    <div className="bg-dark-bg min-h-screen pt-24 pb-24 px-4 overflow-hidden">
      <div className="max-w-7xl mx-auto relative">
        <div className="absolute top-0 -left-64 w-96 h-96 bg-amber-accent/5 rounded-full blur-[120px]" />
        
        <header className="mb-16 border-l-8 border-amber-accent pl-8 relative z-10">
          <motion.h1 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="font-serif text-5xl md:text-7xl font-bold text-white mb-4 tracking-tighter"
          >
            THE PEAK <span className="text-amber-accent italic font-light">Collection</span>
          </motion.h1>
          <p className="text-slate-500 font-bold uppercase tracking-[0.3em] text-[10px]">Namaste Nepal Premium Expeditions</p>
        </header>

        {/* Search and Filters */}
        <div className="bg-dark-surface p-4 rounded-3xl shadow-2xl border border-slate-800/50 mb-12 flex flex-col md:flex-row gap-6 relative z-10">
          <div className="flex-grow relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
            <input 
              type="text" 
              placeholder="Search by route, region, or peak..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-14 pr-6 py-4 bg-dark-bg border border-slate-800/50 rounded-2xl focus:ring-2 focus:ring-amber-accent/20 text-sm outline-none transition-all focus:border-amber-accent/30"
            />
          </div>
          <div className="flex gap-4">
            <select 
              value={durationFilter}
              onChange={(e) => setDurationFilter(e.target.value)}
              className="px-6 py-4 bg-dark-bg border border-slate-800/50 rounded-2xl text-sm focus:ring-2 focus:ring-amber-accent/20 outline-none hover:border-amber-accent/30 transition-all font-bold uppercase tracking-widest text-[10px]"
            >
              <option value="all">Any Duration</option>
              <option value="07 Days">07 Days</option>
              <option value="10 Days">10 Days</option>
              <option value="14 Days">14 Days</option>
              <option value="21 Days">21 Days</option>
            </select>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-6 py-4 bg-dark-bg border border-slate-800/50 rounded-2xl text-sm focus:ring-2 focus:ring-amber-accent/20 outline-none hover:border-amber-accent/30 transition-all font-bold uppercase tracking-widest text-[10px]"
            >
              <option value="rating">Top Rated</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 relative z-10">
          {loading ? (
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="bg-dark-card rounded-[3rem] h-[500px] animate-pulse border border-slate-800/50" />
            ))
          ) : (
            filteredTreks.map((trek) => (
              <motion.div
                key={trek.id}
                whileHover={{ y: -12 }}
                className="group dark-card overflow-hidden"
              >
                <div className="relative aspect-[4/5] overflow-hidden">
                  <img src={trek.images[0]} alt={trek.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70 group-hover:opacity-100" />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-bg via-transparent to-transparent opacity-80" />
                  
                  <div className="absolute top-6 right-6 bg-dark-bg/80 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center space-x-1 border border-slate-700/50">
                    <Star className="w-3 h-3 text-amber-accent fill-current" />
                    <span className="text-[10px] font-black">{trek.rating}</span>
                  </div>
                  
                  <div className="absolute bottom-6 left-6 flex flex-wrap gap-2">
                    {trek.tags.map(tag => (
                      <span key={tag} className="text-[9px] font-black uppercase tracking-[0.2em] bg-amber-accent text-black px-2 py-1 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <button 
                    onClick={() => fetchTrekDetail(trek.id)}
                    className="absolute top-6 left-6 w-10 h-10 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-amber-accent hover:text-black transition-all"
                  >
                    <Info className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-10">
                  <div className="flex items-center space-x-2 text-amber-accent mb-4">
                    <MapPin className="w-4 h-4" />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">{trek.location}</span>
                    {trek.duration && (
                      <>
                        <span className="text-slate-700">•</span>
                        <Clock className="w-4 h-4" />
                        <span className="text-[10px] font-black uppercase tracking-[0.2em]">{trek.duration}</span>
                      </>
                    )}
                  </div>
                  <h3 className="font-serif text-3xl font-bold mb-4 text-white group-hover:text-amber-accent transition-colors leading-tight">{trek.name}</h3>
                  <p className="text-slate-500 text-sm font-light leading-relaxed mb-10 line-clamp-2">{trek.description}</p>
                  
                  <div className="flex items-center justify-between pt-8 border-t border-slate-800/50">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-widest mb-1">Starting from</span>
                      <span className="text-2xl font-serif font-bold text-white">${trek.price.toLocaleString()}</span>
                    </div>
                    <Link to={`/booking/${trek.id}`} className="bg-white text-black px-8 py-4 rounded-full text-xs font-black uppercase tracking-widest hover:bg-amber-accent transition-all shadow-xl shadow-amber-accent/10">
                      Reserve
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      {/* Trek Details Modal */}
      <AnimatePresence>
        {selectedDetail && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedDetail(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-4xl max-h-[90vh] bg-dark-card border border-slate-800 rounded-[3rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.8)] flex flex-col"
            >
              <button 
                onClick={() => setSelectedDetail(null)}
                className="absolute top-6 right-6 p-3 bg-slate-800/50 hover:bg-amber-accent hover:text-black rounded-full transition-colors text-white z-10"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex-grow overflow-y-auto p-8 md:p-12">
                <div className="flex items-center space-x-3 text-amber-accent mb-6 uppercase tracking-[0.3em] text-[10px] font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Expedition Dossier</span>
                  <span className="text-slate-700">•</span>
                  <Thermometer className="w-4 h-4" />
                  <span>Difficulty: {selectedDetail.difficulty}</span>
                </div>

                <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-12">
                  Trek <span className="text-amber-accent italic font-light">Deep Dive</span>
                </h2>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  {/* Itinerary */}
                  <div className="space-y-8">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-10 h-10 bg-amber-accent/10 rounded-xl flex items-center justify-center text-amber-accent">
                        <ChevronRight className="w-6 h-6" />
                      </div>
                      <h3 className="font-serif text-2xl font-bold text-white">Itinerary</h3>
                    </div>
                    
                    <div className="space-y-6">
                      {selectedDetail.itinerary.map((day) => (
                        <div key={day.day} className="flex space-x-4 group">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center text-xs font-bold text-amber-accent border border-slate-700 group-hover:bg-amber-accent group-hover:text-black transition-colors">
                              {day.day}
                            </div>
                            <div className="w-px h-full bg-slate-800 min-h-[40px] my-1" />
                          </div>
                          <div>
                            <h4 className="text-white font-bold text-sm mb-1">{day.title}</h4>
                            <p className="text-slate-500 text-xs leading-relaxed">{day.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Requirements & Packing */}
                  <div className="space-y-12">
                    <section>
                      <div className="flex items-center space-x-3 mb-6">
                         <div className="w-10 h-10 bg-amber-accent/10 rounded-xl flex items-center justify-center text-amber-accent">
                          <ClipboardList className="w-6 h-6" />
                        </div>
                        <h3 className="font-serif text-2xl font-bold text-white">Required Permits</h3>
                      </div>
                      <ul className="space-y-3">
                        {selectedDetail.permits.map(permit => (
                          <li key={permit} className="flex items-center space-x-3 text-slate-400 text-sm">
                            <div className="w-1.5 h-1.5 bg-amber-accent rounded-full" />
                            <span>{permit}</span>
                          </li>
                        ))}
                      </ul>
                    </section>

                    <section>
                      <div className="flex items-center space-x-3 mb-6">
                         <div className="w-10 h-10 bg-amber-accent/10 rounded-xl flex items-center justify-center text-amber-accent">
                          <Mountain className="w-6 h-6" />
                        </div>
                        <h3 className="font-serif text-2xl font-bold text-white">Packing List</h3>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {selectedDetail.packingList.map(item => (
                          <span key={item} className="px-4 py-2 bg-slate-800/50 border border-slate-700 text-slate-300 text-[10px] rounded-xl font-bold uppercase tracking-widest">
                            {item}
                          </span>
                        ))}
                      </div>
                    </section>
                  </div>
                </div>
              </div>

              <div className="p-8 md:p-12 bg-dark-surface border-t border-slate-800 flex items-center justify-between">
                <div>
                   <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-2">Best Window</p>
                   <div className="flex space-x-2">
                      {selectedDetail.bestTime.map(time => (
                        <span key={time} className="text-white font-serif text-xl font-bold">{time}</span>
                      ))}
                   </div>
                </div>
                <Link 
                  to={`/booking/${selectedDetail.id}`}
                  className="bg-amber-accent text-black px-10 py-4 rounded-full font-black uppercase tracking-widest text-xs hover:bg-white transition-all shadow-xl shadow-amber-accent/20"
                >
                  Start Expedition
                </Link>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default TrekExplorer;
