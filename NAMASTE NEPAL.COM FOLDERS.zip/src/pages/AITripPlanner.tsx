import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Compass, Calendar, Wallet, Dumbbell, MapPin, Download, Loader2, PartyPopper } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

const AITripPlanner = () => {
  const [loading, setLoading] = useState(false);
  const [itinerary, setItinerary] = useState<string | null>(null);
  const [form, setForm] = useState({
    fitness: 'moderate',
    duration: '14',
    budget: 'mid-range',
    interest: 'adventure',
    season: 'Autumn'
  });

  const generateItinerary = async () => {
    setLoading(true);
    setItinerary(null);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Generate a detailed day-by-day Nepal travel itinerary for someone with ${form.fitness} fitness level. 
        Duration: ${form.duration} days. 
        Budget: ${form.budget}. 
        Primary Interest: ${form.interest}. 
        Season: ${form.season}.
        Include:
        1. Daily breakdown with locations and activities.
        2. Estimated daily costs in NPR.
        3. Cultural tips for these specific locations.
        4. Packing essentials for this season.
        Format the output in professional, clean Markdown with clear headings.`
      });
      setItinerary(response.text || "I couldn't generate a response.");
    } catch (error) {
      console.error(error);
      setItinerary("The mountain spirits are shy today. Please try again in a moment.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg text-slate-200 py-40 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="inline-flex items-center space-x-3 bg-amber-accent/10 px-6 py-2 rounded-full text-amber-accent mb-8 border border-amber-accent/20"
          >
            <Sparkles className="w-5 h-5 animate-pulse" />
            <span className="text-[10px] uppercase font-bold tracking-[0.3em]">Next-Gen Travel Intelligence</span>
          </motion.div>
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-white mb-8 tracking-tighter leading-none">
            AI TRIP <span className="text-amber-accent italic font-light">ARCHITECT</span>
          </h1>
          <p className="text-slate-500 max-w-2xl mx-auto font-light leading-relaxed">
            Harness the power of neural networks to craft your perfect Himalayan expedition. 
            Personalized routes, real-time climate data, and cultural synchronization.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Controls */}
          <div className="lg:col-span-4 space-y-8">
            <div className="dark-card p-10 space-y-10 border-amber-accent/10">
              <div className="space-y-6">
                <label className="flex items-center space-x-3 text-white font-serif text-xl font-bold">
                  <Dumbbell className="w-5 h-5 text-amber-accent" />
                  <span>Fitness Level</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {['Easy', 'Moderate', 'Challenging', 'Elite'].map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => setForm({...form, fitness: lvl})}
                      className={`px-4 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest border transition-all ${
                        form.fitness === lvl 
                          ? 'bg-amber-accent text-black border-amber-accent' 
                          : 'bg-dark-bg border-slate-800 text-slate-500 hover:border-slate-700'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <label className="flex items-center space-x-3 text-white font-serif text-xl font-bold">
                  <Calendar className="w-5 h-5 text-amber-accent" />
                  <span>Duration (Days)</span>
                </label>
                <input 
                  type="range" min="3" max="30" value={form.duration} 
                  onChange={(e) => setForm({...form, duration: e.target.value})}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-accent"
                />
                <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest">
                   <span>3 Days</span>
                   <span className="text-amber-accent text-sm">{form.duration} Days</span>
                   <span>30 Days</span>
                </div>
              </div>

              <div className="space-y-6">
                <label className="flex items-center space-x-3 text-white font-serif text-xl font-bold">
                  <Wallet className="w-5 h-5 text-amber-accent" />
                  <span>Budget Tier</span>
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {['Budget', 'Mid', 'Luxury'].map(tier => (
                    <button
                      key={tier}
                      onClick={() => setForm({...form, budget: tier})}
                      className={`py-3 rounded-xl text-[10px] font-bold uppercase border transition-all ${
                        form.budget === tier 
                          ? 'bg-amber-accent text-black border-amber-accent' 
                          : 'bg-dark-bg border-slate-800 text-slate-500'
                      }`}
                    >
                      {tier}
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={generateItinerary}
                disabled={loading}
                className="w-full bg-amber-accent text-black py-6 rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-2xl shadow-amber-accent/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center space-x-3 disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <PartyPopper className="w-5 h-5" />
                    <span>Conceive Itinerary</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Results */}
          <div className="lg:col-span-8 min-h-[600px]">
            <AnimatePresence mode="wait">
              {loading ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full h-full flex flex-col items-center justify-center space-y-8 bg-dark-card rounded-[3rem] border border-slate-800/50"
                >
                  <div className="relative">
                    <div className="w-24 h-24 border-4 border-amber-accent/20 border-t-amber-accent rounded-full animate-spin" />
                    <Compass className="absolute inset-0 m-auto w-10 h-10 text-amber-accent animate-pulse" />
                  </div>
                  <div className="text-center">
                    <p className="font-serif text-2xl font-bold text-white mb-2 italic">Scanning Mountain Peaks...</p>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Optimizing logistics & cultural sync</p>
                  </div>
                </motion.div>
              ) : itinerary ? (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-dark-card rounded-[3rem] border border-slate-800/50 overflow-hidden flex flex-col"
                >
                  <div className="p-8 md:p-12 border-b border-slate-800 flex items-center justify-between bg-dark-surface/30">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-amber-accent text-black rounded-2xl flex items-center justify-center">
                        <Calendar className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="font-serif text-3xl font-bold text-white">Your Expedition</h2>
                        <p className="text-[10px] text-amber-accent font-bold uppercase tracking-widest">Generated by Namaste AI</p>
                      </div>
                    </div>
                    <button className="p-4 bg-slate-800 text-white rounded-2xl hover:bg-amber-accent hover:text-black transition-all">
                      <Download className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-8 md:p-16 overflow-y-auto max-h-[800px] prose prose-invert prose-amber max-w-none prose-headings:font-serif prose-headings:text-amber-accent">
                    <ReactMarkdown>{itinerary}</ReactMarkdown>
                  </div>
                </motion.div>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-dark-card rounded-[3rem] border border-dashed border-slate-800 p-12 text-center">
                  <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mb-8 border border-slate-700/50">
                    <MapPin className="w-10 h-10 text-slate-700" />
                  </div>
                  <h3 className="font-serif text-4xl font-bold text-slate-400 mb-4 italic">No Plan Conceived Yet</h3>
                  <p className="text-slate-600 max-w-xs font-light">Set your parameters and let Namaste AI blueprint your adventure.</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AITripPlanner;
