import React from 'react';
import { motion } from 'motion/react';
import { Globe, Heart, Sunrise, Users } from 'lucide-react';

const About = () => {
  const sections = [
    {
      title: "Geographical Grandeur",
      icon: Globe,
      content: "Nepal is a landlocked mountain kingdom located between China to the north and India to the south. It is home to eight of the world's ten tallest peaks, including Mount Everest. The variety of its topography is unmatched, ranging from the tropical Terai plains to the subarctic Himalayan peaks.",
      color: "bg-amber-accent"
    },
    {
      title: "Cultural Mosaic",
      icon: Users,
      content: "With over 125 ethnic groups and as many languages, Nepal is a vibrant tapestry of cultures. The harmony between Hinduism and Buddhism is unique, with many shared sacred sites like Muktinath and Swayambhunath.",
      color: "bg-amber-accent"
    },
    {
      title: "The Birthplace of Peace",
      icon: Sunrise,
      content: "Lumbini, located in the Terai region, is the birthplace of Siddhartha Gautama, the Lord Buddha. It is a UNESCO World Heritage site and a center for pilgrimage for people seeking enlightenment from around the world.",
      color: "bg-amber-accent"
    }
  ];

  return (
    <div className="bg-dark-bg min-h-screen text-slate-200">
      {/* Dynamic Header */}
      <div className="bg-dark-surface py-40 px-4 relative overflow-hidden border-b border-slate-800/50">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=2000')] bg-cover bg-center opacity-10" />
        <div className="max-w-4xl mx-auto relative z-10 text-center">
          <motion.span 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             className="text-amber-accent text-xs font-bold uppercase tracking-[0.3em] mb-6 block"
          >
            अतिथी देवो भव: (Guest is God)
          </motion.span>
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="font-serif text-5xl md:text-8xl font-bold text-white mb-8 tracking-tighter"
          >
            LAND OF THE <span className="text-amber-accent italic font-light">HIMALAYAS</span>
          </motion.h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-32">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-40">
          {sections.map((s, i) => (
            <motion.div 
              key={i}
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className={`w-16 h-16 ${s.color} rounded-2xl flex items-center justify-center mb-10 shadow-2xl text-black group-hover:scale-110 transition-transform shadow-amber-accent/20`}>
                <s.icon className="w-8 h-8" />
              </div>
              <h3 className="font-serif text-3xl font-bold mb-6 text-white">{s.title}</h3>
              <p className="text-slate-400 leading-relaxed text-sm font-light">{s.content}</p>
            </motion.div>
          ))}
        </div>

        {/* Cultural Detail */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center bg-dark-card rounded-[4rem] p-12 md:p-24 overflow-hidden relative border border-slate-800/50">
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-accent/5 rounded-full blur-[100px] -mr-48 -mt-48" />
          <div>
            <span className="text-amber-accent font-bold text-[10px] uppercase tracking-[0.2em] block mb-6">Namaste Spirit</span>
            <h2 className="font-serif text-4xl md:text-5xl font-bold mb-10 text-white italic leading-tight">The Essence of <br /> Nepalese Hospitality</h2>
            <div className="space-y-8">
              <p className="text-slate-400 font-light leading-relaxed">
                In Nepal, we don't just welcome tourists; we welcome souls. "Namaste" – loosely translated as "I bow to the divine in you" – is the heartbeat of our interaction, a sacred acknowledgment of the light within each traveler.
              </p>
              <ul className="space-y-5">
                {[
                  "Traditional Newari and Sherpa cuisines",
                  "Vibrant festivals like Dashain and Tihar",
                  "Living heritage of Kathmandu Valley",
                  "Unmatched biodiversity in National Parks"
                ].map(item => (
                  <li key={item} className="flex items-center space-x-4 text-slate-300 font-medium text-sm">
                    <div className="w-1.5 h-1.5 bg-amber-accent rounded-full shadow-[0_0_10px_rgba(245,158,11,0.5)]" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="relative group">
            <div className="aspect-square bg-slate-800 rounded-3xl overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.5)] border border-slate-700/50">
               <img 
                 src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1000&auto=format&fit=crop" 
                 alt="Nepal Culture" 
                 className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-700"
               />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-amber-accent text-black px-10 py-6 rounded-2xl shadow-2xl font-black uppercase tracking-widest text-xs rotate-6 group-hover:rotate-0 transition-transform">
               Sacred Lumbini
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
