import React, { useState } from 'react';
import { Languages, Banknote, RefreshCcw, ArrowRightLeft } from 'lucide-react';
import { motion } from 'motion/react';

const UtilityHub = () => {
  const [currency, setCurrency] = useState({ amount: 1, from: 'USD', to: 'NPR', result: 133.5 });
  const [translation, setTranslation] = useState({ text: '', result: '' });

  const convertCurrency = async () => {
    // Simulating API call to the server I created
    const res = await fetch(`/api/convert?amount=${currency.amount}&from=${currency.from}&to=${currency.to}`);
    const data = await res.json();
    setCurrency({ ...currency, result: data.result });
  };

  const translateText = async () => {
     // Mock translation for demo
     const dictionary: Record<string, string> = {
       'hello': 'Namaste',
       'thank you': 'Dhanyabaad',
       'water': 'Paani',
       'food': 'Khana',
       'how much': 'Kati ho?',
       'beautiful': 'Ramro'
     };
     const word = translation.text.toLowerCase().trim();
     setTranslation({ ...translation, result: dictionary[word] || "Searching cultural database..." });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-24">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Currency Converter */}
        <div className="dark-card p-10">
           <div className="flex items-center space-x-4 mb-10">
              <div className="w-12 h-12 bg-amber-accent/10 rounded-2xl flex items-center justify-center text-amber-accent shadow-lg shadow-amber-accent/10">
                 <Banknote className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-2xl text-white">Currency Hub</h3>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Real-time NPR conversion</p>
              </div>
           </div>
           
           <div className="space-y-6">
              <div className="flex items-center space-x-4">
                 <div className="flex-grow">
                    <input 
                       type="number" 
                       value={currency.amount}
                       onChange={(e) => setCurrency({...currency, amount: parseFloat(e.target.value)})}
                       className="w-full p-5 bg-dark-bg rounded-2xl border border-slate-800 focus:ring-2 focus:ring-amber-accent/20 outline-none transition-all text-white font-bold"
                    />
                 </div>
                 <select 
                    value={currency.from}
                    onChange={(e) => setCurrency({...currency, from: e.target.value})}
                    className="p-5 bg-dark-bg rounded-2xl border border-slate-800 focus:ring-2 focus:ring-amber-accent/20 outline-none transition-all text-slate-400 font-bold uppercase text-xs"
                 >
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="INR">INR</option>
                 </select>
              </div>

              <div className="flex justify-center">
                 <button onClick={convertCurrency} className="p-3 bg-amber-accent text-black rounded-full hover:bg-white transition-all shadow-xl shadow-amber-accent/20">
                    <RefreshCcw className="w-5 h-5" />
                 </button>
              </div>

              <div className="flex items-center space-x-4">
                 <div className="flex-grow p-6 bg-slate-800/50 text-amber-accent border border-slate-700/50 rounded-2xl text-center font-serif text-3xl font-bold">
                    {currency.result.toFixed(2)} <span className="text-sm font-sans font-bold text-slate-500">NPR</span>
                 </div>
              </div>
           </div>
        </div>

        {/* Translator */}
        <div className="dark-card p-10">
           <div className="flex items-center space-x-4 mb-10">
              <div className="w-12 h-12 bg-amber-accent/10 rounded-2xl flex items-center justify-center text-amber-accent shadow-lg shadow-amber-accent/10">
                 <Languages className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-2xl text-white">Cultural Bridge</h3>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">English to Nepali Phrases</p>
              </div>
           </div>

           <div className="space-y-6">
              <div className="relative">
                 <input 
                    type="text" 
                    placeholder="Type in English (try: Hello, Water...)"
                    value={translation.text}
                    onChange={(e) => setTranslation({...translation, text: e.target.value})}
                    className="w-full p-5 pr-16 bg-dark-bg rounded-2xl border border-slate-800 focus:ring-2 focus:ring-amber-accent/20 outline-none transition-all text-white placeholder:text-slate-700"
                 />
                 <button 
                    onClick={translateText}
                    className="absolute right-3 top-1/2 -translate-y-1/2 bg-amber-accent text-black p-2.5 rounded-xl transition-all hover:bg-white shadow-lg shadow-amber-accent/10"
                 >
                    <ArrowRightLeft className="w-5 h-5" />
                 </button>
              </div>

              <div className="p-10 bg-dark-bg rounded-[2rem] text-center border border-slate-800/50 group">
                  <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-black mb-4">Nepali Translation</p>
                   <p className="font-serif text-4xl font-bold text-amber-accent italic group-hover:scale-105 transition-transform duration-500">
                    {translation.result || '---'}
                  </p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default UtilityHub;
