import React from 'react';
import { Mountain, Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-dark-surface text-white pt-24 pb-12 border-t border-slate-800/30">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-8 group">
              <Mountain className="w-8 h-8 text-amber-accent" />
               <div className="leading-tight">
                <span className="font-serif font-bold text-xl tracking-wider text-amber-accent block">NAMASTE</span>
                <span className="font-serif font-light text-sm tracking-widest text-slate-500 block -mt-1">NEPAL</span>
              </div>
            </Link>
            <p className="text-slate-500 text-sm leading-relaxed mb-8 font-light">
              Your comprehensive guide to the spiritual and physical peaks of the Himalayas. Discover Nepal with authentic local insights and AI-powered planning.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-2.5 bg-white/5 rounded-xl hover:bg-amber-accent hover:text-black transition-all"><Facebook className="w-4 h-4" /></a>
              <a href="#" className="p-2.5 bg-white/5 rounded-xl hover:bg-amber-accent hover:text-black transition-all"><Instagram className="w-4 h-4" /></a>
              <a href="#" className="p-2.5 bg-white/5 rounded-xl hover:bg-amber-accent hover:text-black transition-all"><Twitter className="w-4 h-4" /></a>
            </div>
          </div>

          <div>
            <h4 className="font-serif font-bold mb-8 text-white uppercase tracking-widest text-xs">Quick Links</h4>
            <ul className="space-y-4 text-xs text-slate-500 font-bold uppercase tracking-widest">
              <li><Link to="/treks" className="hover:text-amber-accent transition-colors">Trekking Routes</Link></li>
              <li><Link to="/hotels" className="hover:text-amber-accent transition-colors">Hotel Booking</Link></li>
              <li><Link to="/guides" className="hover:text-amber-accent transition-colors">Local Guides</Link></li>
              <li><Link to="/mountaineering" className="hover:text-amber-accent transition-colors">Expeditions</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif font-bold mb-8 text-white uppercase tracking-widest text-xs">Destinations</h4>
            <ul className="space-y-4 text-xs text-slate-500 font-bold uppercase tracking-widest">
              <li><a href="#" className="hover:text-amber-accent transition-colors">Everest Region</a></li>
              <li><a href="#" className="hover:text-amber-accent transition-colors">Annapurna Circuit</a></li>
              <li><a href="#" className="hover:text-amber-accent transition-colors">Lumbini Heritage</a></li>
              <li><a href="#" className="hover:text-amber-accent transition-colors">Kathmandu Valley</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif font-bold mb-8 text-white uppercase tracking-widest text-xs">Expedition HQ</h4>
            <div className="space-y-5 text-sm text-slate-500 font-light">
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 mt-1 text-amber-accent" />
                <span>Thamel, Kathmandu, Nepal</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-amber-accent" />
                <span>+977-1-4XXXXXX</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-amber-accent" />
                <span>contact@namastenepal.com</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-slate-800/50 pt-8 flex flex-col md:row items-center justify-between gap-6">
          <p className="text-[10px] text-slate-600 uppercase tracking-widest font-bold">
            © {new Date().getFullYear()} Namaste Nepal Expedition Group.
          </p>
          <div className="flex items-center space-x-8 text-[10px] text-slate-600 uppercase tracking-widest font-bold">
             <a href="#" className="hover:text-white transition-colors">Privacy</a>
             <a href="#" className="hover:text-white transition-colors">Terms</a>
             <div className="flex items-center space-x-4">
                <span className="text-slate-700">Payment Gateway</span>
                <div className="flex items-center space-x-2">
                   <div className="w-8 h-4 bg-green-900/30 text-green-500 text-[8px] flex items-center justify-center rounded border border-green-500/20">eSewa</div>
                   <div className="w-8 h-4 bg-purple-900/30 text-purple-400 text-[8px] flex items-center justify-center rounded border border-purple-400/20">Khalti</div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
