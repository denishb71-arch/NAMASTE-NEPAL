import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { Menu, X, User, Mountain, Globe, LogIn, LogOut, Sparkles, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const Navbar = () => {
  const { user, signInWithGoogle, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-dark-bg/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center space-x-2 group">
            <Mountain className="w-8 h-8 text-amber-accent transition-transform group-hover:scale-110" />
            <div className="leading-tight">
              <span className="font-serif font-bold text-xl tracking-wider text-amber-accent block">NAMASTE</span>
              <span className="font-serif font-light text-sm tracking-widest text-slate-400 block -mt-1">NEPAL</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/treks" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Treks</Link>
            <Link to="/mountaineering" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Expeditions</Link>
            <Link to="/ai-planner" className="flex items-center space-x-2 px-4 py-2 bg-amber-accent/10 rounded-full border border-amber-accent/20 text-amber-accent hover:bg-amber-accent hover:text-black transition-all">
              <Sparkles className="w-4 h-4" />
              <span className="text-[10px] uppercase font-black tracking-widest">AI Planner</span>
            </Link>
            <Link to="/toolkit" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Toolkit</Link>
            <Link to="/emergency" className="flex items-center space-x-2 px-4 py-2 bg-red-500/10 rounded-full border border-red-500/20 text-red-500 hover:bg-red-500 hover:text-white transition-all">
              <AlertCircle className="w-4 h-4" />
              <span className="text-[10px] uppercase font-black tracking-widest">SOS</span>
            </Link>
            <Link to="/agencies" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Agencies</Link>
            <Link to="/hotels" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Hotels</Link>
            <Link to="/guides" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Guides</Link>
            <Link to="/about" className="text-xs uppercase tracking-widest font-bold text-slate-300 hover:text-amber-accent transition-colors">Culture</Link>

            {user ? (
              <div className="flex items-center space-x-4 border-l border-slate-800 pl-8">
                {user.role === 'admin' && (
                  <Link to="/admin" className="text-[10px] uppercase tracking-[0.2em] font-black text-slate-500 hover:text-amber-accent">Admin</Link>
                )}
                <div className="flex items-center space-x-3">
                   <img src={user.photoURL} alt={user.displayName} className="w-8 h-8 rounded-full border border-slate-700 shadow-sm" />
                   <button onClick={logout} className="text-slate-400 hover:text-amber-accent transition-colors"><LogOut className="w-4 h-4" /></button>
                </div>
              </div>
            ) : (
              <button 
                onClick={signInWithGoogle}
                className="flex items-center space-x-2 bg-white text-black px-6 py-2 rounded-full text-xs font-bold hover:bg-amber-accent transition-all hover:scale-105 active:scale-95"
              >
                <LogIn className="w-4 h-4" />
                <span>Join Now</span>
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 p-2">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-slate-200 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              <Link to="/treks" className="block px-3 py-2 text-base font-medium text-slate-700" onClick={() => setIsOpen(false)}>Treks</Link>
              <Link to="/mountaineering" className="block px-3 py-2 text-base font-medium text-slate-700" onClick={() => setIsOpen(false)}>Mountaineering</Link>
              <Link to="/hotels" className="block px-3 py-2 text-base font-medium text-slate-700" onClick={() => setIsOpen(false)}>Hotels</Link>
              <Link to="/guides" className="block px-3 py-2 text-base font-medium text-slate-700" onClick={() => setIsOpen(false)}>Guides</Link>
              <Link to="/about" className="block px-3 py-2 text-base font-medium text-slate-700" onClick={() => setIsOpen(false)}>About Nepal</Link>
              {!user && (
                <button 
                   onClick={() => { signInWithGoogle(); setIsOpen(false); }}
                   className="w-full text-left px-3 py-2 text-base font-medium text-nepal-red flex items-center space-x-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Sign In</span>
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
