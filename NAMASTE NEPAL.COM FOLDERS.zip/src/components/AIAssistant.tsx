import React, { useState, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { MessageSquare, Send, X, Bot, Image as ImageIcon, Paperclip } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string; image?: string }[]>([
    { role: 'assistant', content: "Namaste! I am your Nepal Trekking Assistant. How can I help you plan your journey through the Himalayas? You can also upload photos of mountains or landmarks for identification!" }
  ]);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage || loading) return;

    const userMessage = input;
    const currentImage = selectedImage;
    setInput('');
    setSelectedImage(null);
    setMessages(prev => [...prev, { role: 'user', content: userMessage, image: currentImage || undefined }]);
    setLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: 'user', parts: [{ text: "You are a specialized travel assistant for Nepal. Help the user with trek planning, location advice, and culture. If the user provides an image, identify the peaks or landmarks in it. Be respectful and detailed." } ] },
          ...messages.map(m => ({
            role: m.role as any,
            parts: [{ text: m.content }]
          })),
          { 
            role: 'user' as const, 
            parts: [
              ...(currentImage ? [{
                inlineData: {
                  mimeType: "image/jpeg",
                  data: currentImage.split(',')[1]
                }
              }] : []),
              { text: userMessage || "What is in this image?" }
            ] 
          }
        ]
      });

      const text = response.text || "I couldn't generate a response.";
      setMessages(prev => [...prev, { role: 'assistant', content: text }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Forgive me, I encountered a disturbance in the mountain air. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            className="fixed bottom-28 right-8 w-96 max-w-[calc(100vw-2rem)] h-[600px] bg-dark-card border border-slate-800 flex flex-col rounded-[2.5rem] shadow-[0_50px_100px_rgba(0,0,0,0.8)] overflow-hidden"
          >
            {/* Header */}
            <div className="p-6 border-b border-slate-800 bg-dark-surface/50 backdrop-blur-md flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-amber-accent rounded-2xl flex items-center justify-center text-black shadow-lg shadow-amber-accent/20">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-white leading-tight">Namaste Assistant</h3>
                  <span className="text-[10px] text-green-500 font-bold uppercase tracking-widest flex items-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-2 animate-pulse" />
                    Active Route Tracking
                  </span>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-slate-800 rounded-xl transition-colors text-slate-500 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide bg-dark-bg/20">
              {messages.map((m, i) => (
                <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                  {m.image && (
                    <div className="mb-2 max-w-[70%] rounded-2xl overflow-hidden border border-slate-700">
                      <img src={m.image} alt="User upload" className="w-full h-auto object-cover" />
                    </div>
                  )}
                  <div className={`max-w-[85%] p-5 rounded-[1.8rem] ${
                    m.role === 'user' 
                      ? 'bg-amber-accent text-black font-medium leading-relaxed rounded-tr-none' 
                      : 'bg-slate-800/40 text-slate-200 text-sm leading-relaxed border border-slate-800/50 rounded-tl-none'
                  }`}>
                    <ReactMarkdown>{m.content}</ReactMarkdown>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-slate-800/40 p-5 rounded-[1.8rem] rounded-tl-none border border-slate-800/50">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-amber-accent/50 rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-amber-accent/50 rounded-full animate-bounce [animation-delay:-0.2s]" />
                      <div className="w-2 h-2 bg-amber-accent/50 rounded-full animate-bounce [animation-delay:-0.4s]" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-6 border-t border-slate-800 bg-dark-surface/50">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageSelect} 
                accept="image/*" 
                className="hidden" 
              />
              
              {selectedImage && (
                <div className="mb-4 relative w-20 h-20 group">
                  <img src={selectedImage} alt="Preview" className="w-full h-full object-cover rounded-xl border border-amber-accent/50" />
                  <button 
                    onClick={() => setSelectedImage(null)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}

              <div className="relative flex items-center space-x-2">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-3 bg-slate-800/50 text-slate-400 rounded-xl hover:text-amber-accent transition-all"
                >
                  <Paperclip className="w-5 h-5" />
                </button>
                <div className="relative flex-grow">
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Describe a peak or ask advice..."
                    className="w-full bg-dark-bg border border-slate-800 rounded-2xl py-4 pl-6 pr-14 text-sm focus:ring-2 focus:ring-amber-accent/20 outline-none transition-all placeholder:text-slate-600 focus:border-amber-accent/30 text-white"
                  />
                  <button 
                    onClick={handleSend}
                    disabled={loading || (!input.trim() && !selectedImage)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-amber-accent text-black rounded-xl hover:bg-white transition-all disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-amber-accent text-black p-5 rounded-full shadow-2xl flex items-center justify-center group border border-white/20"
      >
        <MessageSquare className="w-6 h-6 group-hover:rotate-12 transition-transform" />
        <span className="w-0 overflow-hidden group-hover:w-auto group-hover:ml-3 transition-all whitespace-nowrap font-bold text-xs uppercase tracking-widest">Namaste AI</span>
      </motion.button>
    </div>
  );
};

export default AIAssistant;
