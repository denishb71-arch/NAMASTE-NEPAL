import React, { useState } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';

const center = {
  lat: 28.3949, // Nepal Center
  lng: 84.1240
};

const mapContainerStyle = {
  width: '100%',
  height: '100%'
};

const RealTimeMap = ({ selectedTrek }: { selectedTrek?: any }) => {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "YOUR_GOOGLE_MAPS_API_KEY" // Placeholder
  });

  const [selectedMarker, setSelectedMarker] = useState<any>(null);

  const treks = [
    { id: 1, name: 'Everest Base Camp', pos: { lat: 27.9881, lng: 86.9250 } },
    { id: 2, name: 'Annapurna Base Camp', pos: { lat: 28.5300, lng: 83.8780 } },
    { id: 3, name: 'Lumbini (Temple)', pos: { lat: 27.4839, lng: 83.2759 } }
  ];

  if (!isLoaded) return <div className="h-full w-full bg-slate-100 animate-pulse flex items-center justify-center">Loading Map...</div>;

  return (
    <GoogleMap
      mapContainerStyle={mapContainerStyle}
      center={selectedTrek?.coordinates || center}
      zoom={selectedTrek ? 10 : 7}
      options={{
        styles: [
            { "featureType": "administrative", "elementType": "all", "stylers": [{ "saturation": "-100" }] },
            { "featureType": "administrative.province", "elementType": "all", "stylers": [{ "visibility": "off" }] },
            { "featureType": "landscape", "elementType": "all", "stylers": [{ "saturation": -100 }, { "lightness": 65 }, { "visibility": "on" }] },
            { "featureType": "poi", "elementType": "all", "stylers": [{ "saturation": -100 }, { "lightness": "50" }, { "visibility": "simplified" }] },
            { "featureType": "road", "elementType": "all", "stylers": [{ "saturation": "-100" }] },
            { "featureType": "road.highway", "elementType": "all", "stylers": [{ "visibility": "simplified" }] },
            { "featureType": "road.arterial", "elementType": "all", "stylers": [{ "lightness": "30" }] },
            { "featureType": "road.local", "elementType": "all", "stylers": [{ "lightness": "40" }] },
            { "featureType": "transit", "elementType": "all", "stylers": [{ "saturation": -100 }, { "visibility": "simplified" }] },
            { "featureType": "water", "elementType": "geometry", "stylers": [{ "hue": "#ffff00" }, { "lightness": -25 }, { "saturation": -97 }] },
            { "featureType": "water", "elementType": "labels", "stylers": [{ "lightness": -25 }, { "saturation": -100 }] }
        ]
      }}
    >
      {treks.map(t => (
        <Marker 
          key={t.id} 
          position={t.pos} 
          onClick={() => setSelectedMarker(t)}
          icon={{
            path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
            fillColor: '#DC143C',
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 1.5,
            anchor: new google.maps.Point(12, 24)
          }}
        />
      ))}

      {selectedMarker && (
        <InfoWindow
          position={selectedMarker.pos}
          onCloseClick={() => setSelectedMarker(null)}
        >
          <div className="p-2">
            <h4 className="font-bold text-slate-900">{selectedMarker.name}</h4>
            <p className="text-xs text-slate-500">Gateway to Adventure</p>
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
};

export default RealTimeMap;
