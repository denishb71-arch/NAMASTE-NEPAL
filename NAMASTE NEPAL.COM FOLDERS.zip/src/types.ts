export type UserRole = 'user' | 'admin' | 'provider';

export interface AppUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  createdAt: any;
}

export interface Service {
  id: string;
  type: 'trek' | 'mountaineering' | 'hotel' | 'agency' | 'guide';
  name: string;
  description: string;
  location: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  price: number;
  currency: string;
  images: string[];
  providerId: string;
  rating: number;
  reviewCount: number;
  tags: string[];
  duration?: string;
}

export interface Booking {
  id: string;
  userId: string;
  providerId: string;
  serviceId: string;
  serviceType: string;
  date: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  amount: number;
  paymentMethod: string;
  createdAt: any;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  serviceId: string;
  rating: number;
  comment: string;
  createdAt: any;
}

export interface TrekDetail {
  id: string;
  itinerary: {
    day: number;
    title: string;
    description: string;
  }[];
  difficulty: 'Easy' | 'Moderate' | 'Challenging' | 'Expert';
  permits: string[];
  packingList: string[];
  bestTime: string[];
}

export interface EmergencyContact {
  id: string;
  userId: string;
  name: string;
  phone: string;
  relationship: string;
  createdAt: any;
}
