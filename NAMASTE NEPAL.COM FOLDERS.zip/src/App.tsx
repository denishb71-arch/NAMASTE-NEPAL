import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { AuthProvider } from './lib/AuthContext';
import Home from './pages/Home';
import TrekExplorer from './pages/TrekExplorer';
import About from './pages/About';
import Booking from './pages/Booking';
import AdminPanel from './pages/Admin';
import ExplorerTemplate from './pages/ExplorerTemplate';
import AITripPlanner from './pages/AITripPlanner';
import Emergency from './pages/Emergency';
import SherpaToolkit from './pages/SherpaToolkit';
import UtilityHub from './components/UtilityHub';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AIAssistant from './components/AIAssistant';

const HomeWithUtilities = () => (
  <div>
    <Home />
    <section className="bg-dark-surface border-t border-slate-800/30">
      <UtilityHub />
    </section>
  </div>
);

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomeWithUtilities />} />
              <Route path="/treks" element={<TrekExplorer />} />
              <Route path="/mountaineering" element={<ExplorerTemplate type="mountaineering" title="Himalayan Expeditions" />} />
              <Route path="/agencies" element={<ExplorerTemplate type="agency" title="Local Agencies" />} />
              <Route path="/hotels" element={<ExplorerTemplate type="hotel" title="Mountain Retreats" />} />
              <Route path="/guides" element={<ExplorerTemplate type="guide" title="Certified Local Experts" />} />
              <Route path="/ai-planner" element={<AITripPlanner />} />
              <Route path="/emergency" element={<Emergency />} />
              <Route path="/toolkit" element={<SherpaToolkit />} />
              <Route path="/about" element={<About />} />
              <Route path="/booking/:id" element={<Booking />} />
              <Route path="/admin" element={<AdminPanel />} />
            </Routes>
          </main>
          <Footer />
          <AIAssistant />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
